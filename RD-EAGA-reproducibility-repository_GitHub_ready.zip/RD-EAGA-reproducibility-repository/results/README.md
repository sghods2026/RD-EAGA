# results/

| Path | Content |
|---|---|
| `benchmark_raw.csv`, `benchmark_summary.csv` | 800 scenario rows (4 topologies x 4 loads x 10 seeds x 5 methods) and their per-scenario summary |
| `seed_runs/seeds_*/10_Seed_Runs/run1..10/` | per-seed outputs that were merged into `benchmark_raw.csv` (run *i* = seed 20260802+*i*) |
| `seed_cluster/` | Tables 10, 11, 19, G1 (regenerate with `scripts/seed_cluster_analysis.py`) |
| `ablation_*.csv`, `table15_bootstrap_ci.csv`, `beta_lambda_sensitivity_*.csv` | ablation and beta-lambda sensitivity |
| `mc_dropout_*.csv`, `mc_score_populations_*.csv` | MC-dropout calibration / T sensitivity |
| `random_compute_robustness_summary.csv` | random compute-node placement robustness |
| `training_sensitivity_seeds*.csv` | Table 21 |
| `generation_sensitivity_seeds*.csv`, `benchmark_replay_check.csv` | Appendix F, replay check |
| `checkpoint_retrain_check.json` | retraining of the distributed checkpoint |
| `statistical_tests.csv`, `table10_bootstrap_ci.csv`, `table11_bootstrap_ci.csv`, `common_success_scenario_stats.csv`, `repetition_stability.csv` | legacy row-level (non seed-cluster) analyses written by `src/postprocess_results.py` / `src/enhancement_checks.py`; the manuscript's Tables 10/11/19 use `seed_cluster/` |
| `core/` | copy of the original core outputs and figures (`03_Results`, `04_Figures`); many files duplicate the top-level ones |
| `superseded/` | earlier analyses replaced by the seed-cluster / multi-seed versions; do not cite |

`run_metadata.json` files of the seed runs show quick-mode defaults (1200 samples / 45 epochs) because those runs used `--skip-training`; the checkpoint was trained with 200 samples / 15 epochs.
