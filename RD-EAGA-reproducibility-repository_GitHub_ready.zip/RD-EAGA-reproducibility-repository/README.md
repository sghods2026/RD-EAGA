# RD-EAGA Reproducibility Repository

Code, data, trained checkpoint and result files for the manuscript

> **RD-EAGA: An Uncertainty- and Diversity-Aware Extension of Embedding-Assisted Genetic Algorithms for Constrained 6G-Style Communication-Computing Networks**

- Repository URL: `TODO: <https://github.com/OWNER/REPO>`
- Archive DOI (Zenodo): `TODO: <10.5281/zenodo.XXXXXXX>`

## Purpose and reproduction boundary
This is an *independent, reduced-profile reimplementation and extension* of the Embedding-Assisted GA (EAGA) idea, not a bit-for-bit reproduction of the source paper (whose code, seeds and trained weights are not public). It contains the methods compared in the manuscript (Dijkstra, CGA, EAGA, RD-EAGA and an ACO-seeded GA proxy), the quality-predictor training code, the benchmark/ablation drivers, the executed raw results, and the analysis scripts for the manuscript tables. Benchmark rows are scenario-level aggregates (no per-demand identifiers); no exact MILP/CSP baseline is included.

**Naming:** the method labelled `HGA-ACO` in code and CSV files is the "ACO-seeded GA proxy" of the manuscript.

## Layout
```
src/eaga_reproduction.py        models, algorithms, training, benchmark, ablation (main entry point)
src/reproduce_executed_profile.sh  executed verification profile (manuscript Appendix A.2)
src/postprocess_results.py      merges runs/run*/ into results/benchmark_raw.csv; legacy tables/figures
src/enhancement_checks.py       Holm/BH adjustment, row-level bootstrap tables, MC-dropout calibration, robustness, 2nd-topology ablation
scripts/seed_cluster_analysis.py        Tables 10, 11, 19, G1 (seed-cluster bootstrap / exact sign-flip / Holm)
scripts/train_size_sensitivity.py       Table 21 (training-size/epoch sensitivity, 5 seeds)
scripts/generation_budget_sensitivity.py  Appendix F, Tables F1-F2 (+ --replay benchmark replay check)
scripts/retrain_checkpoint_check.py     retrains the checkpoint and compares with models/population_quality_gmm.pt
scripts/make_figures.py                 manuscript figures (PDF + 600 dpi PNG) -> figures/
data/topologies/*.gml           public SNDlib/TopoHub topologies (abilene, geant, janos-us-ca, giul39, germany50)
models/                         distributed checkpoint (200 samples, 15 epochs, seed 20260803) + training history
results/                        executed outputs (see results/README.md)
results/seed_runs/              the ten per-seed benchmark runs (seeds 20260803-20260812)
results/seed_cluster/           regenerated Tables 10, 11, 19, G1
results/superseded/             earlier analyses kept only for traceability - do not cite
figures/                        manuscript figures (vector PDF + PNG)
environment/requirements.txt    pinned dependencies
patches/load_topology.patch     diff of the topology-loader fix (already applied in src/)
```

## Install
Tested with Python 3.13 (Linux x86-64, CPU). Python >= 3.11 is required by the pinned numpy/scipy.
```bash
python -m venv .venv && source .venv/bin/activate        # Windows: .venv\Scripts\activate
# optional but recommended (small CPU-only wheel, as used for the published results):
pip install torch==2.10.0 --index-url https://download.pytorch.org/whl/cpu
pip install -r environment/requirements.txt
```
Without the first line, `pip` installs the default `torch==2.10.0` wheel (CUDA build on Linux, ~GB-sized); results do not depend on a GPU, which is never used. All pins were checked to exist on PyPI and to resolve together on Python 3.13.

## Quick smoke test (~15 s)
```bash
python src/eaga_reproduction.py --output /tmp/smoke --quick --topology-source bundled \
    --train-samples 20 --epochs 2 --repetitions 1 --ablation-repetitions 1 --loads 10 --workers 1
```
This trains a tiny model, runs a 4-topology benchmark and an ablation, and writes CSV/PNG files to `/tmp/smoke`. Use `--topology-source bundled` to fail loudly if a topology file is missing; with `auto` the code falls back to a synthetic surrogate graph (with a warning) and results would *not* match the published ones.

## Executed verification profile (manuscript Appendix A.2)
```bash
cp -r . ../rdeaga_run && cd ../rdeaga_run      # run in a COPY: the script overwrites models/ and results/
PYTHON=python3 WORKERS=4 bash src/reproduce_executed_profile.sh
```
It (1) trains the checkpoint (200 samples, 15 epochs), (2) runs ten benchmark seeds 20260803-20260812 (`runs/run1..10`, 4 topologies x loads 50/75/100/200, 1 repetition each) with `--skip-training`, (3) runs the 10-repetition ablation, (4) merges the runs with `src/postprocess_results.py`. Measured wall time on a 2-core CPU machine: ~4 min. The archived seed runs in `results/seed_runs/` are the outputs of step 2 (named `run1..run10` in two folders); `runs/` is the corresponding scratch location used by the script.

Single seed example (~15 s on 2 cores), using the shipped checkpoint:
```bash
python src/eaga_reproduction.py --output /tmp/run1 --quick --topology-source bundled --skip-training \
   --checkpoint models/population_quality_gmm.pt --skip-ablation --repetitions 1 --loads 50 75 100 200 --workers 2 --seed 20260803
```
The full paper-parameter profile of Appendix A.3 (10000 samples, 250 epochs, 100 repetitions) is provided but was **not** executed.

## Reproducing the manuscript tables
| Table | Command (repository root) | Output |
|---|---|---|
| 10, 11, 19, G1 | `python scripts/seed_cluster_analysis.py --raw results/benchmark_raw.csv --out results/seed_cluster` (~1 s; 20,000 bootstrap draws, rng seed 20260803) | `results/seed_cluster/table10_method_means.csv`, `table11_relative_change.csv`, `table19_seed_cluster_tests.csv`, `tableG1_failure_penalised_utility.csv` |
| 21 | `python scripts/train_size_sensitivity.py --out results/training_sensitivity_seeds.csv` (30 trainings; one seed = 6 trainings took 16 s, ~1.5 min estimated for all 5 seeds) | `results/training_sensitivity_seeds*.csv` |
| F1, F2 | (~25 s on 2 cores) `python scripts/generation_budget_sensitivity.py --out results/generation_sensitivity_seeds.csv --replay results/benchmark_replay_check.csv` | `results/generation_sensitivity_seeds*.csv`, `results/benchmark_replay_check.csv` |
| Checkpoint check | `python scripts/retrain_checkpoint_check.py --out results/checkpoint_retrain_check.json` (~2 min) | retrained vs. distributed checkpoint: MAE 4.1527, MAPE 27.45 %, max weight difference 6e-7 |
| Figures | `python scripts/make_figures.py` | `figures/` |

Smoke-test options: `train_size_sensitivity.py --n-seeds 1 --samples 50 --epochs 5`, `generation_budget_sensitivity.py --n-seeds 1 --budgets 5 --demands 5`.

## Determinism notes
- Dijkstra, CGA, EAGA and the ACO-seeded GA proxy reproduce the archived `results/benchmark_raw.csv` **exactly** (success, cost, delay, throughput, generations) for the same seeds; only runtime columns vary with hardware.
- RD-EAGA uses MC-dropout whose masks are drawn from the *global* torch RNG, so it reproduces only **in distribution** (small differences in individual scenarios; overall means agree to within ~0.1 %).
- Seeds: ten root seeds 20260803-20260812; scenario seed = root + 100000*topology_index + 100*load + repetition.
- `results/seed_runs/*/run*/results/run_metadata.json` shows quick-mode defaults (1200 samples / 45 epochs) because those runs used `--skip-training`; the checkpoint itself was trained with 200 samples / 15 epochs (see `results/core/03_Results/training_metrics.json` and `models/`).
- The published results used the CPU build of torch 2.10.0; other builds may differ in floating-point round-off (checkpoint weights agree to ~6e-7).

## Data
The five SNDlib/TopoHub topologies are in `data/topologies/`. `load_topology` searches `data/` and `data/topologies/`. Please check the SNDlib/TopoHub terms of use before redistributing the data (TODO for the owner).

## Citation / license
See `CITATION.cff` (author fields to be completed by the owner) and `LICENSE` (MIT). `CHANGELOG.md` lists changes relative to the original archive.
