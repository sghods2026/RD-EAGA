#!/usr/bin/env python3
"""Training-size / epoch sensitivity of the population-quality predictor (Table 21).

Fixed protocol (all values logged): training topology germany50; quick GA profile
(population 10, max generations 15, stagnation 3, path pool 15, candidate populations 4);
80/20 train/validation split via torch.randperm after global seeding; hidden 64, 4 GMM kernels,
dropout 0.15, batch 32, Adam lr 1e-3; samples in {50,100,200}, epochs in {5,15};
seeds 20260803..20260807 (the seed controls dataset generation, split and initialisation).
Usage (repo root): python scripts/train_size_sensitivity.py [--out results/training_sensitivity_seeds.csv]
Smoke test: --n-seeds 1 --samples 50 --epochs 5 --out /tmp/ts.csv
"""
import argparse, sys, time, tempfile, json
from pathlib import Path
import numpy as np, pandas as pd
ap=argparse.ArgumentParser(); ap.add_argument("--repo",default=str(Path(__file__).resolve().parent.parent)); ap.add_argument("--out",default="results/training_sensitivity_seeds.csv")
ap.add_argument("--n-seeds",type=int,default=5,help="number of seeds starting at 20260803 (default 5 = 20260803..20260807)")
ap.add_argument("--samples",type=int,nargs="+",default=[50,100,200]); ap.add_argument("--epochs",type=int,nargs="+",default=[5,15])
a=ap.parse_args(); sys.path.insert(0,str(Path(a.repo)/"src"))
import eaga_reproduction as er
ga=er.GAConfig(); ga.generations=15; ga.stagnation=3; ga.path_pool_size=15; ga.candidate_populations=4
topo=er.load_topology("germany50","bundled"); rows=[]
for seed in range(20260803,20260803+a.n_seeds):
    for n in a.samples:
        for ep in a.epochs:
            cfg=er.TrainConfig(samples=n,epochs=ep); t=time.time()
            with tempfile.TemporaryDirectory() as td:
                _,m,_=er.train_quality_model(topo,ga,cfg,seed,Path(td))
            rows.append(dict(seed=seed,samples=n,epochs=ep,val_mae_fitness=m["val_mae_fitness"],val_mape=m["val_mape"],best_val_loss=m["best_val_loss"],training_seconds=m["training_seconds"]))
            print(rows[-1],flush=True)
d=pd.DataFrame(rows); d.to_csv(a.out,index=False)
s=d.groupby(["samples","epochs"]).agg(mae_mean=("val_mae_fitness","mean"),mae_sd=("val_mae_fitness","std"),mape_mean=("val_mape","mean"),mape_sd=("val_mape","std"),loss_mean=("best_val_loss","mean"),time_mean=("training_seconds","mean")).reset_index()
s.to_csv(str(a.out).replace(".csv","_summary.csv"),index=False); print(s)
