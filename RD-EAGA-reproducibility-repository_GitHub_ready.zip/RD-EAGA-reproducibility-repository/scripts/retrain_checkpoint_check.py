#!/usr/bin/env python3
"""Retrain the main-benchmark checkpoint (germany50, 200 samples, 15 epochs, seed 20260803, quick GA
profile) and compare it with the distributed models/population_quality_gmm.pt.

Usage (from the repository root):
    python scripts/retrain_checkpoint_check.py [--repo .] [--out results/checkpoint_retrain_check.json]
                                               [--seed 20260803] [--samples 200] [--epochs 15]
"""
import argparse, json, sys, tempfile, time
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--repo", default=str(Path(__file__).resolve().parent.parent))
ap.add_argument("--out", default=None, help="JSON output (default: <repo>/results/checkpoint_retrain_check.json)")
ap.add_argument("--seed", type=int, default=20260803)
ap.add_argument("--samples", type=int, default=200)
ap.add_argument("--epochs", type=int, default=15)
a = ap.parse_args()
repo = Path(a.repo).resolve()
sys.path.insert(0, str(repo / "src"))
import torch
import eaga_reproduction as er

ga = er.GAConfig(); ga.generations = 15; ga.stagnation = 3; ga.path_pool_size = 15; ga.candidate_populations = 4
topo = er.load_topology("germany50", "bundled")
cfg = er.TrainConfig(samples=a.samples, epochs=a.epochs)
t = time.time()
with tempfile.TemporaryDirectory() as td:
    bundle, m, _ = er.train_quality_model(topo, ga, cfg, a.seed, Path(td))
wall = time.time() - t
ref_path = repo / "models" / "population_quality_gmm.pt"
ref = torch.load(ref_path, map_location="cpu", weights_only=False)
diff = max(float((bundle.model.state_dict()[k].float() - v.float()).abs().max()) for k, v in ref["state_dict"].items())
res = {
    "configuration": f"germany50, {a.samples} samples, {a.epochs} epochs, root seed {a.seed}, quick GA profile, bundled GML topologies",
    "torch": torch.__version__,
    "retrained": {"val_mae_fitness": m["val_mae_fitness"], "val_mape": m["val_mape"], "best_val_loss": m["best_val_loss"],
                  "label_mean": bundle.label_mean, "label_std": bundle.label_std},
    "distributed_checkpoint": {"label_mean": ref["label_mean"], "label_std": ref["label_std"]},
    "max_abs_weight_difference": diff,
    "wall_seconds": wall,
}
print(json.dumps(res, indent=2))
if a.out:
    Path(a.out).write_text(json.dumps(res, indent=2))
