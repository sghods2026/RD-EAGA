#!/usr/bin/env python3
"""GA generation-budget sensitivity (Appendix F) with fully logged seeds, plus a one-scenario benchmark replay check.

Abilene, 30 sequential demands, methods CGA / EAGA / RD-EAGA, shared archived checkpoint, ten root seeds
20260803-20260812 (scenario seed = root + 100*30, as in the benchmark: base_seed = root + 100000*topo_idx + 100*load + rep).
Budgets (max generations) 5, 10, 15, 30; two stopping regimes: (a) executed profile, stagnation = 3;
(b) no early stop, stagnation = budget.  Usage (repo root): python scripts/generation_budget_sensitivity.py [--out results/generation_sensitivity_seeds.csv] [--replay results/benchmark_replay_check.csv]
Smoke test: --n-seeds 1 --budgets 5 --demands 5 --out /tmp/g.csv
"""
import argparse, sys, copy
from pathlib import Path
import numpy as np, pandas as pd
ap=argparse.ArgumentParser(); ap.add_argument("--repo",default=str(Path(__file__).resolve().parent.parent)); ap.add_argument("--out",default="results/generation_sensitivity_seeds.csv")
ap.add_argument("--n-seeds",type=int,default=10,help="number of seeds starting at 20260803 (default 10)")
ap.add_argument("--budgets",type=int,nargs="+",default=[5,10,15,30]); ap.add_argument("--demands",type=int,default=30)
ap.add_argument("--replay-only",action="store_true",help="run only the replay check (requires --replay)")
ap.add_argument("--replay",default=None,help="optional csv for benchmark replay check")
a=ap.parse_args(); repo=Path(a.repo); sys.path.insert(0,str(repo/"src"))
import eaga_reproduction as er
bundle=er.load_quality_model(repo/"models"/"population_quality_gmm.pt")
base_ga=er.GAConfig(); base_ga.generations=15; base_ga.stagnation=3; base_ga.path_pool_size=15; base_ga.candidate_populations=4
if a.replay:
    raw=pd.read_csv(repo/"results"/"benchmark_raw.csv"); out=[]
    for topo_i,topo in enumerate(["abilene","geant","janos-us-ca","giul39"]):
        for load in (50,):
            for i in (0,1):
                rows=er._benchmark_scenario((bundle,base_ga,topo,load,0,"bundled",20260803+i,topo_i))
                for r in rows:
                    ref=raw[(raw.topology==topo)&(raw.load==load)&(raw.seed==20260803+i)&(raw.method==r["method"])].iloc[0]
                    out.append(dict(topology=topo,load=load,seed=20260803+i,method=r["method"],
                        d_success=r["success_rate"]-ref.success_rate,d_cost=np.nan_to_num(r["avg_cost"])-np.nan_to_num(ref.avg_cost),d_delay=np.nan_to_num(r["avg_delay"])-np.nan_to_num(ref.avg_delay)))
    pd.DataFrame(out).to_csv(a.replay,index=False); print(pd.DataFrame(out).describe().T[["max","min"]])
topo=er.load_topology("abilene","bundled"); rows=[]
for seed in ([] if a.replay_only else range(20260803,20260803+a.n_seeds)):
    base_seed=seed+0*100000+30*100  # scenario seed offset 100*30, see module docstring
    base=er.NetworkState(topo,seed=base_seed); demands=[base.sample_demand() for _ in range(a.demands)]
    for regime in ("stagnation3","no_early_stop"):
        for G in a.budgets:
            ga=copy.deepcopy(base_ga); ga.generations=G; ga.stagnation=3 if regime=="stagnation3" else G
            for mi,m in enumerate(["CGA","EAGA","RD-EAGA"]):
                state=base.clone(); per=[er.solve_one(m,state,d,ga,base_seed+{"CGA":1,"EAGA":2,"RD-EAGA":4}[m]*10000+j,bundle) for j,d in enumerate(demands)]
                df=pd.DataFrame(per); s=df[df.success==True]
                rows.append(dict(seed=seed,regime=regime,generations=G,method=m,success_rate=df.success.mean(),avg_cost=s.cost.mean(),avg_delay=s.delay.mean(),runtime_ms=df.runtime.mean()*1000,avg_generations=df.generations.mean()))
if a.replay_only: sys.exit(0)
d=pd.DataFrame(rows); d.to_csv(a.out,index=False)
g=d.groupby(["regime","generations","method"]).agg(success=("success_rate","mean"),cost=("avg_cost","mean"),delay=("avg_delay","mean"),runtime_ms=("runtime_ms","mean"),gens=("avg_generations","mean")).reset_index()
g.to_csv(str(a.out).replace(".csv","_summary.csv"),index=False); pd.set_option("display.width",200); print(g.round(4).to_string())
