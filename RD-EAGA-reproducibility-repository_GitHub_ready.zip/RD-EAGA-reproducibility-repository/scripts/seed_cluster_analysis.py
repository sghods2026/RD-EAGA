#!/usr/bin/env python3
"""Seed-cluster confirmatory analysis for the RD-EAGA manuscript (Tables 10, 11, 19, G1).

Unit of resampling / blocking: the seed identifier (20260803-20260812). The same ten seeds are
used in every one of the 16 topology x load strata, so each seed is a replicate cluster that
carries its complete 16-stratum block.

* Cluster bootstrap : B draws; each draw samples 10 seed ids with replacement and keeps all
  16 strata (and all method rows) of every selected seed.
* Exact sign-flip   : all 2^10 seed-level sign assignments applied to the ten seed-level mean
  paired differences (two-sided, |mean| >= |observed|).
* Cohen dz          : mean / sd of the ten seed-level paired mean differences.
* Holm              : step-down across the 20 contrasts (4 baselines x 5 metrics), and across
  the 16 penalty-by-baseline contrasts for the failure-penalised utility.
* Failure-penalised utility U_P = s*C + (1-s)*P  (s = scenario success rate, C = mean cost
  conditional on success, P in {25,30,40,50}); a scenario-level expected-cost sensitivity.

Usage: python seed_cluster_analysis.py --raw results/benchmark_raw.csv --out results/seed_cluster
"""
import argparse, itertools, os
import numpy as np, pandas as pd

METRICS = {"success_rate": "Success rate", "avg_cost": "Cost", "avg_delay": "Delay (ms)",
           "avg_throughput": "ABRC (Gbps)", "avg_runtime": "Runtime"}
FOCAL = "RD-EAGA"
BASES = ["CGA", "EAGA", "HGA-ACO", "Dijkstra"]          # HGA-ACO = "ACO-seeded GA proxy" in the paper
PENALTIES = [25, 30, 40, 50]


def holm(p):
    p = np.asarray(p, float); order = np.argsort(p); m = len(p); adj = np.empty(m); run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (m - rank) * p[i]); adj[i] = min(1.0, run)
    return adj


def seed_means(diff_by_row, seeds):
    return np.array([diff_by_row[diff_by_row.seed == s]["d"].mean() for s in seeds])


def cluster_stats(sm, B, rng):
    n = len(sm)
    idx = rng.integers(0, n, size=(B, n))
    boot = sm[idx].mean(axis=1)
    lo, hi = np.percentile(boot, [2.5, 97.5])
    signs = np.array(list(itertools.product([1, -1], repeat=n)))
    flips = np.abs((signs * sm).mean(axis=1))
    p = np.mean(flips >= abs(sm.mean()) - 1e-12)
    dz = sm.mean() / sm.std(ddof=1) if sm.std(ddof=1) > 0 else np.nan
    return sm.mean(), lo, hi, dz, p


def paired(raw, base, col):
    a = raw[raw.method == FOCAL].set_index(["topology", "load", "seed"])[col]
    b = raw[raw.method == base].set_index(["topology", "load", "seed"])[col]
    return (a - b).rename("d").reset_index()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--draws", type=int, default=20000); ap.add_argument("--rng", type=int, default=20260803)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    raw = pd.read_csv(a.raw); seeds = sorted(raw.seed.unique())
    assert len(raw) == 800 and len(seeds) == 10
    rng = np.random.default_rng(a.rng)

    rows = []
    for base in BASES:
        for col in METRICS:
            d = paired(raw, base, col); sm = seed_means(d, seeds)
            m, lo, hi, dz, p = cluster_stats(sm, a.draws, rng)
            rows.append(dict(baseline=base, metric=col, mean_diff=m, ci95_low=lo, ci95_high=hi,
                             cohen_dz_seed=dz, exact_signflip_p=p))
    t19 = pd.DataFrame(rows); t19["p_holm"] = holm(t19.exact_signflip_p.values)
    t19.to_csv(f"{a.out}/table19_seed_cluster_tests.csv", index=False)

    # Table 11: paired relative change (mean over the 160 pairs); success in percentage points
    rows = []
    for base in BASES:
        for col in METRICS:
            A = raw[raw.method == FOCAL].set_index(["topology", "load", "seed"])[col]
            Bv = raw[raw.method == base].set_index(["topology", "load", "seed"])[col]
            if col == "success_rate":
                d = ((A - Bv) * 100).rename("d").reset_index()
            else:
                ok = Bv != 0
                d = ((A[ok] - Bv[ok]) / Bv[ok] * 100).rename("d").reset_index()
            sm = seed_means(d, seeds); m, lo, hi, _, _ = cluster_stats(sm, a.draws, rng)
            rows.append(dict(baseline=base, metric=col, mean_rel_change=d.d.mean(), ci95_low=lo, ci95_high=hi))
    pd.DataFrame(rows).to_csv(f"{a.out}/table11_relative_change.csv", index=False)

    # Table 10: method means with seed-cluster bootstrap CIs
    rows = []
    for meth in raw.method.unique():
        r = dict(method=meth)
        for col in list(METRICS) + ["avg_generations"]:
            sm = np.array([raw[(raw.method == meth) & (raw.seed == s)][col].mean() for s in seeds])
            boot = sm[rng.integers(0, 10, size=(a.draws, 10))].mean(axis=1)
            r[col] = sm.mean(); r[col + "_lo"], r[col + "_hi"] = np.percentile(boot, [2.5, 97.5])
        rows.append(r)
    pd.DataFrame(rows).to_csv(f"{a.out}/table10_method_means.csv", index=False)

    # Table G1: failure-penalised utility
    rows = []
    for P in PENALTIES:
        U = raw.assign(U=raw.success_rate * raw.avg_cost + (1 - raw.success_rate) * P)
        for base in BASES:
            d = paired(U, base, "U"); sm = seed_means(d, seeds)
            m, lo, hi, dz, p = cluster_stats(sm, a.draws, rng)
            rows.append(dict(penalty=P, baseline=base, mean_delta_U=m, ci95_low=lo, ci95_high=hi,
                             cohen_dz_seed=dz, exact_signflip_p=p))
    g1 = pd.DataFrame(rows); g1["p_holm"] = holm(g1.exact_signflip_p.values)
    g1.to_csv(f"{a.out}/tableG1_failure_penalised_utility.csv", index=False)
    print("done ->", a.out)

if __name__ == "__main__":
    main()
