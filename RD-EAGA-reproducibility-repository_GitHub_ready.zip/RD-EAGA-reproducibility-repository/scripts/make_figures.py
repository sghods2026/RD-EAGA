import matplotlib; matplotlib.use("Agg")
import argparse, os
import matplotlib.pyplot as plt, pandas as pd, numpy as np
from matplotlib.patches import FancyBboxPatch
from PIL import Image
ap=argparse.ArgumentParser(description="Regenerate the manuscript figures (PDF + 600-dpi PNG) from the shipped results.")
ap.add_argument("--repo",default=os.path.join(os.path.dirname(os.path.abspath(__file__)),".."))
ap.add_argument("--out",default=None,help="output directory (default: <repo>/figures)")
ap.add_argument("--training-size-summary",default=None,help="default: <repo>/results/training_sensitivity_seeds_summary.csv")
A=ap.parse_args()
R=os.path.join(os.path.abspath(A.repo),"")
OUT=A.out or R+"figures"; os.makedirs(OUT,exist_ok=True)
plt.rcParams.update({"font.family":"serif","font.size":6.5,"axes.titlesize":7,"axes.labelsize":6.5,"xtick.labelsize":6,"ytick.labelsize":6,"legend.fontsize":6,"axes.linewidth":0.6,"lines.linewidth":1.0,"lines.markersize":3})
W=3.1; DPI=600
def save(fig,slot,name):
    fig.savefig(f"{OUT}/{name}.pdf"); fig.savefig(f"{OUT}/{name}.png",dpi=DPI)
    im=Image.open(f"{OUT}/{name}.png").convert("RGB")
    print(name,im.size)
    plt.close(fig)
# Fig 1
fig,ax=plt.subplots(figsize=(W,2.5)); ax.set_xlim(0,100); ax.set_ylim(0,80); ax.axis("off")
def box(x,y,w,h,t):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="square,pad=0",fc="white",ec="black",lw=0.7)); ax.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=5.8)
def arr(a,b): ax.annotate("",xy=b,xytext=a,arrowprops=dict(arrowstyle="->",lw=0.7))
box(0,58,31,18,"Network state\nnode + edge\nfeatures"); box(0,30,31,18,"Candidate\npopulations\n(path chromosomes)")
box(35,58,30,18,"GMM edge-aware\ngraph encoder"); box(35,30,30,18,"Population FNN\nencoder + pooling")
box(70,38,30,30,"Joint predictor\nmean + MC-dropout\nuncertainty (μ, σ)")
box(0,2,56,18,"Uncertainty–diversity score\nS = μ + β·σ + λ·(1 − D)"); box(66,2,34,18,"Path-pool GA\nselection, mutation,\nelitism")
arr((31,67),(35,67)); arr((31,39),(35,39)); arr((65,67),(70,60)); arr((65,39),(70,46)); arr((85,38),(40,20)); arr((56,11),(66,11))
save(fig,"image2.jpeg","fig01_architecture"); h1=2.5
# Fig 3 training
h=pd.read_csv(R+"models/training_history.csv"); fig,ax=plt.subplots(figsize=(W,2.1))
ax.plot(h.epoch,h.train_loss,label="Train"); ax.plot(h.epoch,h.val_loss,label="Validation"); ax.set_xlabel("Epoch"); ax.set_ylabel("Smooth L1 loss"); ax.grid(alpha=.3,lw=.4); ax.legend(frameon=False)
fig.tight_layout(pad=.4); save(fig,"image4.jpeg","fig03_training")
# Figs 4-8
s=pd.read_csv(R+"results/benchmark_summary.csv"); s["method"]=s.method.replace({"HGA-ACO":"ACO-seeded GA proxy"})
order=["Dijkstra","CGA","EAGA","ACO-seeded GA proxy","RD-EAGA"]; cols=["#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd"]
for slot,met,yl,sc,name in [("image5.png","success_rate","Routing success rate",1,"fig04_success"),("image6.png","avg_cost","Average cost (cost units)",1,"fig05_cost"),("image7.png","avg_delay","Average delay (ms)",1,"fig06_delay"),("image8.png","avg_throughput","ABRC (Gbps)",1,"fig07_abrc"),("image9.png","avg_runtime","Runtime (ms / attempted demand)",1000,"fig08_runtime")]:
    fig,axs=plt.subplots(2,2,figsize=(W,3.5))
    for ax,topo in zip(axs.flat,["abilene","geant","janos-us-ca","giul39"]):
        for m,c in zip(order,cols):
            q=s[(s.topology==topo)&(s.method==m)].sort_values("load")
            ax.errorbar(q.load+(order.index(m)-2)*2,q[met+"_mean"]*sc,yerr=q[met+"_ci95"]*sc,marker="o",color=c,label=m,capsize=1.5,elinewidth=.5,lw=.8)
        ax.set_title(topo); ax.set_xticks([50,75,100,200]); ax.grid(alpha=.3,lw=.4)
    for ax in axs[1]: ax.set_xlabel("Number of demands")
    for ax in axs[:,0]: ax.set_ylabel(yl)
    h_,l_=axs[0,0].get_legend_handles_labels(); fig.legend(h_,l_,loc="upper center",ncol=3,frameon=False,handlelength=1.2,columnspacing=.8)
    fig.tight_layout(rect=(0,0,1,.89),pad=.4,h_pad=.6,w_pad=.5); save(fig,slot,name)
# Fig 9 ablation (3 stacked)
t=pd.read_csv(R+"results/table15_bootstrap_ci.csv"); o=["Full RD-EAGA","No uncertainty","No diversity","No edge features","Population-only scorer","Random initialization"]; t=t.set_index("variant").loc[o]
fig,axs=plt.subplots(1,3,figsize=(W,2.2))
for ax,(m,ti) in zip(axs,[("success_rate","Success rate"),("avg_cost","Average cost"),("avg_delay","Average delay (ms)")]):
    mu=t[m+"_mean"]; ax.bar(range(6),mu,yerr=[mu-t[m+"_ci95_low"],t[m+"_ci95_high"]-mu],capsize=1.5,color="#1f77b4",error_kw=dict(lw=.5)); ax.set_title(ti,fontsize=6.5)
    ax.set_xticks(range(6)); ax.set_xticklabels(o,rotation=60,ha="right",fontsize=4.8); ax.tick_params(axis="y",labelsize=5.5); ax.grid(axis="y",alpha=.3,lw=.4)
fig.tight_layout(pad=.3,w_pad=.4); save(fig,"image10.jpeg","fig09_ablation")
# Fig 10 seed-cluster
t19=pd.read_csv(R+"results/seed_cluster/table19_seed_cluster_tests.csv"); t19=t19[t19.metric=="avg_cost"].set_index("baseline")
b=[(("ACO-seeded GA proxy" if k=="HGA-ACO" else k),t19.loc[k,"mean_diff"],t19.loc[k,"ci95_low"],t19.loc[k,"ci95_high"]) for k in ["Dijkstra","CGA","EAGA","HGA-ACO"]]
fig,ax=plt.subplots(figsize=(W,1.9))
for i,(n,m,lo,hi) in enumerate(b[::-1]):
    c={"Dijkstra":"#1f77b4","CGA":"#ff7f0e","EAGA":"#2ca02c","ACO-seeded GA proxy":"#d62728"}[n]
    ax.errorbar(m,i,xerr=[[m-lo],[hi-m]],fmt="o",color=c,capsize=2,elinewidth=.8)
ax.axvline(0,lw=.6); ax.set_yticks(range(4)); ax.set_yticklabels([x[0] for x in b[::-1]]); ax.set_xlabel("Cost difference (RD-EAGA − baseline)"); ax.grid(axis="x",alpha=.3,lw=.4)
fig.tight_layout(pad=.4); save(fig,"image11.jpeg","fig10_seedcluster")
# Fig 11 calibration
c=pd.read_csv(R+"results/mc_dropout_calibration_summary.csv"); fig,ax=plt.subplots(figsize=(W,2.1))
ax.plot(range(3),c.pearson_r,"o-",label="Pearson r"); ax.plot(range(3),c.spearman_rho,"s-",label="Spearman ρ")
for i,r in c.iterrows(): ax.annotate(f"p={r.pearson_p:.3f}",(i,r.pearson_r),textcoords="offset points",xytext=(0,3),ha="center",fontsize=5.5); ax.annotate(f"p={r.spearman_p:.3f}",(i,r.spearman_rho),textcoords="offset points",xytext=(0,-8),ha="center",fontsize=5.5)
ax.axhline(0,lw=.5); ax.set_xticks(range(3)); ax.set_xticklabels(["3","10","20"]); ax.set_xlabel("MC-dropout samples T"); ax.set_ylabel("Correlation with abs. error"); ax.set_xlim(-.3,2.3); ax.legend(frameon=False,loc="upper right"); ax.grid(alpha=.3,lw=.4)
fig.tight_layout(pad=.4); save(fig,"image12.png","fig11_calibration")
# Fig 12 heatmap
bl=pd.read_csv(R+"results/beta_lambda_sensitivity_summary.csv",skiprows=[1]).iloc[:,:3]; bl.columns=["beta","lam","sr"]; bl=bl.astype(float)
pv=bl.pivot(index="beta",columns="lam",values="sr").sort_index(ascending=False)
fig,ax=plt.subplots(figsize=(W,2.3)); im=ax.imshow(pv.values,cmap="viridis",vmin=0.70,vmax=0.76,aspect="auto")
ax.set_xticks(range(5)); ax.set_xticklabels([f"{x:g}" for x in pv.columns]); ax.set_yticks(range(5)); ax.set_yticklabels([f"{x:g}" for x in pv.index]); ax.set_xlabel("λ"); ax.set_ylabel("β")
for (i,j),v in np.ndenumerate(pv.values): ax.text(j,i,f"{v:.3f}",ha="center",va="center",color="white" if v<0.735 else "black",fontsize=5.5)
cb=fig.colorbar(im,ax=ax,pad=.02); cb.set_label("success rate",fontsize=6); cb.ax.tick_params(labelsize=5.5)
fig.tight_layout(pad=.4); save(fig,"image13.png","fig12_beta_lambda")
ts=pd.read_csv(A.training_size_summary or R+"results/training_sensitivity_seeds_summary.csv"); fig,ax=plt.subplots(figsize=(W,2.1))
for e in [5,15]:
    q=ts[ts.epochs==e]; ax.errorbar(q.samples,q.mape_mean*100,yerr=q.mape_sd*100,marker="o",capsize=2,elinewidth=.6,label=f"{e} epochs")
ax.set_xticks([50,100,200]); ax.set_xlabel("Training samples"); ax.set_ylabel("Validation MAPE (%)"); ax.legend(frameon=False); ax.grid(alpha=.3,lw=.4)
fig.tight_layout(pad=.4); save(fig,"image14.png","fig13_training_size")
