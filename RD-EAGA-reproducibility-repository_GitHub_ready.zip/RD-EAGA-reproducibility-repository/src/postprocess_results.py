from __future__ import annotations

from pathlib import Path
import json
import sys

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from scipy import stats

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"], "font.size": 10})

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
DATA = ROOT / "data" / "topologies"  # released layout; falls back to data/ if the files are there
if not DATA.exists():
    DATA = ROOT / "data"
METHODS = ["Dijkstra", "CGA", "EAGA", "HGA-ACO", "RD-EAGA"]
METHOD_LABELS = {
    "Dijkstra": "Dijkstra",
    "CGA": "CGA",
    "EAGA": "EAGA",
    "HGA-ACO": "HGA-ACO",
    "RD-EAGA": "RD-EAGA",
}


def merge_runs() -> pd.DataFrame:
    frames = []
    for i in range(1, 11):
        p = ROOT / "runs" / f"run{i}" / "results" / "benchmark_raw.csv"
        if not p.exists():
            raise FileNotFoundError(p)
        df = pd.read_csv(p)
        df["repetition"] = i - 1
        df["seed"] = 20260802 + i
        frames.append(df)
    raw = pd.concat(frames, ignore_index=True)
    raw = raw.sort_values(["topology", "load", "repetition", "method"]).reset_index(drop=True)
    raw.to_csv(RESULTS / "benchmark_raw.csv", index=False)
    return raw


def summarize(raw: pd.DataFrame) -> pd.DataFrame:
    group_cols = ["topology", "method", "load"]
    metrics = ["success_rate", "total_cost", "avg_cost", "avg_delay", "avg_throughput", "avg_runtime", "avg_generations", "avg_uncertainty"]
    rows = []
    for keys, group in raw.groupby(group_cols, sort=True):
        row = dict(zip(group_cols, keys))
        for metric in metrics:
            values = group[metric].dropna().to_numpy(float)
            row[f"{metric}_mean"] = float(np.mean(values)) if len(values) else np.nan
            row[f"{metric}_std"] = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
            row[f"{metric}_ci95"] = (
                float(stats.t.ppf(0.975, len(values) - 1) * np.std(values, ddof=1) / np.sqrt(len(values)))
                if len(values) > 1 else 0.0
            )
        row["n"] = len(group)
        rows.append(row)
    summary = pd.DataFrame(rows)
    summary.to_csv(RESULTS / "benchmark_summary.csv", index=False)
    return summary


def method_overall(summary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for method, g in summary.groupby("method"):
        rows.append({
            "method": method,
            "success_rate_mean": g["success_rate_mean"].mean(),
            "success_rate_std_across_scenarios": g["success_rate_mean"].std(ddof=1),
            "avg_cost_mean": g["avg_cost_mean"].mean(),
            "avg_delay_mean": g["avg_delay_mean"].mean(),
            "avg_throughput_mean": g["avg_throughput_mean"].mean(),
            "avg_runtime_mean": g["avg_runtime_mean"].mean(),
            "avg_generations_mean": g["avg_generations_mean"].mean(),
        })
    out = pd.DataFrame(rows).sort_values("success_rate_mean", ascending=False)
    out.to_csv(RESULTS / "overall_method_summary.csv", index=False)
    return out


def paired_tests(raw: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for other in ["Dijkstra", "CGA", "EAGA", "HGA-ACO"]:
        a = raw[raw.method == "RD-EAGA"].set_index(["topology", "load", "repetition"])
        b = raw[raw.method == other].set_index(["topology", "load", "repetition"])
        common = a.index.intersection(b.index)
        for metric in ["success_rate", "avg_cost", "avg_delay", "avg_throughput", "avg_runtime"]:
            x = a.loc[common, metric].to_numpy(float)
            y = b.loc[common, metric].to_numpy(float)
            mask = np.isfinite(x) & np.isfinite(y)
            x, y = x[mask], y[mask]
            diff = x - y
            try:
                test = stats.wilcoxon(diff, zero_method="wilcox") if np.any(diff != 0) else None
            except Exception:
                test = None
            q = np.quantile(diff, [0.025, 0.975]) if len(diff) else [np.nan, np.nan]
            rows.append({
                "comparison": f"RD-EAGA vs {other}",
                "metric": metric,
                "n": len(diff),
                "mean_difference": float(np.mean(diff)) if len(diff) else np.nan,
                "median_difference": float(np.median(diff)) if len(diff) else np.nan,
                "empirical_95pct_low": q[0],
                "empirical_95pct_high": q[1],
                "wilcoxon_statistic": getattr(test, "statistic", np.nan),
                "wilcoxon_p": getattr(test, "pvalue", np.nan),
            })
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS / "statistical_tests.csv", index=False)
    return out


def relative_changes(summary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for other in ["CGA", "EAGA", "HGA-ACO", "Dijkstra"]:
        a = summary[summary.method == "RD-EAGA"].set_index(["topology", "load"])
        b = summary[summary.method == other].set_index(["topology", "load"])
        c = a.join(b, lsuffix="_rd", rsuffix="_other")
        rows.append({
            "baseline": other,
            "success_abs_change_pp": 100 * (c.success_rate_mean_rd - c.success_rate_mean_other).mean(),
            "cost_relative_change_pct": 100 * ((c.avg_cost_mean_rd - c.avg_cost_mean_other) / c.avg_cost_mean_other).mean(),
            "delay_relative_change_pct": 100 * ((c.avg_delay_mean_rd - c.avg_delay_mean_other) / c.avg_delay_mean_other).mean(),
            "throughput_relative_change_pct": 100 * ((c.avg_throughput_mean_rd - c.avg_throughput_mean_other) / c.avg_throughput_mean_other).mean(),
            "runtime_relative_change_pct": 100 * ((c.avg_runtime_mean_rd - c.avg_runtime_mean_other) / c.avg_runtime_mean_other).mean(),
        })
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS / "relative_improvements.csv", index=False)
    return out


def plot_metric_panels(summary: pd.DataFrame, metric: str, ylabel: str, filename: str) -> None:
    topologies = ["abilene", "geant", "janos-us-ca", "giul39"]
    fig, axes = plt.subplots(2, 2, figsize=(11.2, 7.5), sharex=True)
    for ax, topo in zip(axes.flat, topologies):
        subset = summary[summary.topology == topo]
        for method in METHODS:
            q = subset[subset.method == method].sort_values("load")
            ax.errorbar(q.load, q[f"{metric}_mean"], yerr=q[f"{metric}_ci95"], marker="o", capsize=2, linewidth=1.5, label=METHOD_LABELS[method])
        ax.set_title(topo)
        ax.set_xlabel("Number of demands")
        ax.set_ylabel(ylabel)
        ax.grid(alpha=0.25)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=5, frameon=False)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(FIGURES / filename, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_topologies() -> None:
    names = ["abilene", "geant", "janos-us-ca", "giul39"]
    fig, axes = plt.subplots(2, 2, figsize=(10.5, 7.8))
    for ax, name in zip(axes.flat, names):
        g = nx.read_gml(DATA / f"{name}.gml", label="id")
        pos = {n: (float(g.nodes[n].get("lon", 0)), float(g.nodes[n].get("lat", 0))) for n in g.nodes}
        nx.draw_networkx_edges(g, pos, ax=ax, width=0.8, alpha=0.65)
        nx.draw_networkx_nodes(g, pos, ax=ax, node_size=55)
        ax.set_title(f"{name}: {g.number_of_nodes()} nodes, {g.number_of_edges()} links")
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(FIGURES / "sndlib_topologies.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_ablation() -> None:
    s = pd.read_csv(RESULTS / "ablation_summary.csv")
    order = ["Full RD-EAGA", "No uncertainty", "No diversity", "No edge features", "Population-only scorer", "Random initialization"]
    s["variant"] = pd.Categorical(s.variant, order, ordered=True)
    s = s.sort_values("variant")
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.4))
    x = np.arange(len(s))
    specs = [
        ("success_rate_mean", "success_rate_std", "Success rate"),
        ("avg_cost_mean", "avg_cost_std", "Average cost"),
        ("avg_delay_mean", "avg_delay_std", "Average latency"),
    ]
    for ax, (mean_col, std_col, title) in zip(axes, specs):
        ax.bar(x, s[mean_col], yerr=s[std_col], capsize=3)
        ax.set_title(title)
        ax.set_xticks(x)
        ax.set_xticklabels([str(v) for v in s.variant], rotation=35, ha="right", fontsize=8)
        ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES / "ablation_panels.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_architecture() -> None:
    fig, ax = plt.subplots(figsize=(11.5, 4.7))
    ax.axis("off")
    boxes = [
        (0.03, 0.58, 0.17, 0.22, "Dynamic network state\nnode + edge features"),
        (0.03, 0.18, 0.17, 0.22, "Candidate populations\npath chromosomes"),
        (0.27, 0.58, 0.18, 0.22, "GMM edge-aware\ngraph encoder"),
        (0.27, 0.18, 0.18, 0.22, "Population FNN\nencoder + pooling"),
        (0.52, 0.38, 0.18, 0.25, "Joint predictor\nmean + MC uncertainty"),
        (0.75, 0.38, 0.20, 0.25, "Risk-diversity score\nmu + beta*sigma + lambda(1-D)"),
        (0.75, 0.07, 0.20, 0.19, "Path-pool GA\nselection, mutation, elitism"),
    ]
    for x, y, w, h, text in boxes:
        patch = plt.Rectangle((x, y), w, h, fill=False, linewidth=1.5)
        ax.add_patch(patch)
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=10)
    arrows = [
        ((0.20, 0.69), (0.27, 0.69)), ((0.20, 0.29), (0.27, 0.29)),
        ((0.45, 0.69), (0.52, 0.53)), ((0.45, 0.29), (0.52, 0.47)),
        ((0.70, 0.505), (0.75, 0.505)), ((0.85, 0.38), (0.85, 0.26)),
    ]
    for a, b in arrows:
        ax.annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle="->", linewidth=1.5))
    ax.set_title("RD-EAGA architecture used in the independent reimplementation", fontsize=13)
    fig.tight_layout()
    fig.savefig(FIGURES / "rd_eaga_architecture.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def selected_tables(summary: pd.DataFrame) -> None:
    cols = ["topology", "method", "success_rate_mean", "success_rate_std", "avg_cost_mean", "avg_delay_mean", "avg_throughput_mean", "avg_runtime_mean"]
    summary[summary.load == 200][cols].sort_values(["topology", "method"]).to_csv(RESULTS / "load200_comparison.csv", index=False)


def metadata() -> None:
    payload = {
        "benchmark_seeds": list(range(20260803, 20260813)),
        "benchmark_repetitions": 10,
        "ablation_repetitions": 10,
        "loads": [50, 75, 100, 200],
        "topologies": ["abilene", "geant", "janos-us-ca", "giul39"],
        "training_topology": "germany50",
        "training_samples_executed": 200,
        "training_epochs_executed": 15,
        "algorithm_profile": "verification/quick: population 10; max generations 15; stagnation 3; path pool 15; candidate populations 4; mutation 0.1; crossover parameter retained in full implementation",
        "topology_source": "bundled exact public TopoHub/SNDlib GML structures",
        "note": "All numerical outputs are generated by the packaged implementation. Exact reconstruction of the source article's plots is impossible without its unpublished code, seeds, demand traces, compute-node assignments, and trained weights.",
    }
    (RESULTS / "executed_profile_metadata.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


def main() -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    raw = merge_runs()
    summary = summarize(raw)
    method_overall(summary)
    paired_tests(raw)
    relative_changes(summary)
    selected_tables(summary)
    metadata()
    plot_topologies()
    plot_architecture()
    plot_metric_panels(summary, "success_rate", "Routing success rate", "success_rate_panels.png")
    plot_metric_panels(summary, "avg_cost", "Average operational cost", "avg_cost_panels.png")
    plot_metric_panels(summary, "avg_delay", "Average latency", "avg_delay_panels.png")
    plot_metric_panels(summary, "avg_throughput", "Average throughput", "throughput_panels.png")
    plot_metric_panels(summary, "avg_runtime", "Runtime per demand (s)", "runtime_panels.png")
    plot_ablation()
    print(f"Wrote {len(raw)} benchmark rows and publication figures to {ROOT}")


if __name__ == "__main__":
    main()
