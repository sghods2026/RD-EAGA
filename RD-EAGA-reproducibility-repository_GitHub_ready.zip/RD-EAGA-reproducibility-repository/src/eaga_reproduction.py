from __future__ import annotations

import argparse
import copy
import concurrent.futures
import json
import math
import os
import random
import time
import warnings
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset


# -----------------------------
# Reproducibility utilities
# -----------------------------

def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(False)


TOPOLOGY_SPECS = {
    "abilene": (12, 15, 101),
    "geant": (22, 36, 203),
    "janos-us-ca": (39, 61, 307),
    "giul39": (39, 86, 401),
    "germany50": (50, 88, 503),
}


def _connected_graph_with_exact_edges(n: int, m: int, seed: int) -> nx.Graph:
    """Deterministic connected geometric surrogate with exactly n nodes and m edges.

    The paper names SNDlib topologies but does not provide edge lists or source code in
    the uploaded article. This fallback preserves node/link counts and broad density.
    If the optional `topohub` package is installed, load_topology() uses the exact
    public topology instead.
    """
    rng = np.random.default_rng(seed)
    pos = {i: tuple(rng.random(2)) for i in range(n)}
    # Start from Euclidean MST for connectivity.
    complete = nx.Graph()
    complete.add_nodes_from(range(n))
    for i in range(n):
        for j in range(i + 1, n):
            d = math.dist(pos[i], pos[j])
            complete.add_edge(i, j, weight=d)
    g = nx.minimum_spanning_tree(complete, weight="weight")
    remaining = sorted(
        ((complete[u][v]["weight"], u, v) for u, v in complete.edges if not g.has_edge(u, v)),
        key=lambda x: (x[0], x[1], x[2]),
    )
    for _, u, v in remaining:
        if g.number_of_edges() >= m:
            break
        g.add_edge(u, v)
    nx.set_node_attributes(g, pos, "pos")
    g.graph["topology_source"] = "deterministic scale-matched surrogate"
    return g


def load_topology(name: str, source: str = "auto") -> nx.Graph:
    key = name.lower()
    if key not in TOPOLOGY_SPECS:
        raise ValueError(f"Unknown topology: {name}")

    # The reproducibility bundle ships the exact public SNDlib topology
    # definitions obtained from TopoHub. This avoids a network dependency.
    # The files are searched in data/ and data/topologies/ (the latter is the
    # layout of the released archive).
    data_dir = Path(__file__).resolve().parent.parent / "data"
    local_gml = next((c for c in (data_dir / f"{key}.gml", data_dir / "topologies" / f"{key}.gml") if c.exists()), None)
    if source == "bundled" and local_gml is None:
        raise FileNotFoundError(f"Bundled topology file for '{key}' not found in {data_dir} or {data_dir / 'topologies'}")
    if source in {"auto", "topohub", "bundled"} and local_gml is not None:
        g = nx.read_gml(local_gml, label="id")
        g = nx.convert_node_labels_to_integers(nx.Graph(g), ordering="sorted")
        g.graph["topology_source"] = "bundled TopoHub/SNDlib GML"
        g.graph["topology_file"] = str(local_gml)
        return g

    if source in {"auto", "topohub"}:
        try:
            import topohub  # type: ignore

            topo = topohub.get(f"sndlib/{key}")
            g = nx.node_link_graph(topo, edges="edges")
            g = nx.convert_node_labels_to_integers(nx.Graph(g), ordering="sorted")
            g.graph["topology_source"] = "TopoHub/SNDlib Python package"
            return g
        except Exception:
            if source == "topohub":
                raise
    if source == "auto":
        warnings.warn(f"No real topology found for '{key}'; using the deterministic scale-matched surrogate graph. Results will NOT match the published results.", RuntimeWarning)
    n, m, seed = TOPOLOGY_SPECS[key]
    return _connected_graph_with_exact_edges(n, m, seed)


@dataclass(frozen=True)
class Demand:
    source: int
    bandwidth: float
    max_delay: float
    min_availability: float
    max_hops: int
    cpu: float
    ram: float
    gpu: float


@dataclass
class GAConfig:
    population_size: int = 10
    generations: int = 100
    stagnation: int = 5
    mutation_rate: float = 0.1
    crossover_rate: float = 0.8
    tournament_size: int = 3
    elite: int = 1
    path_pool_size: int = 35
    penalty_scale: float = 100.0
    candidate_populations: int = 8


@dataclass
class TrainConfig:
    samples: int = 2500
    epochs: int = 80
    batch_size: int = 32
    learning_rate: float = 1e-3
    hidden: int = 64
    kernels: int = 4
    dropout: float = 0.15
    validation_fraction: float = 0.2


class NetworkState:
    def __init__(self, topology: nx.Graph, compute_fraction: float = 0.13, seed: int = 0):
        self.g = copy.deepcopy(topology)
        self.rng = np.random.default_rng(seed)
        nodes = list(self.g.nodes)
        k = max(2, int(round(len(nodes) * compute_fraction)))
        # Deterministic high-degree compute nodes with a random tie-break.
        degrees = sorted(nodes, key=lambda x: (-self.g.degree(x), x))
        self.compute_nodes = set(degrees[:k])
        self._assign_dynamic_attributes()

    def clone(self) -> "NetworkState":
        obj = object.__new__(NetworkState)
        obj.g = copy.deepcopy(self.g)
        obj.rng = np.random.default_rng(0)
        obj.compute_nodes = set(self.compute_nodes)
        return obj

    def _assign_dynamic_attributes(self) -> None:
        for n in self.g.nodes:
            is_compute = n in self.compute_nodes
            self.g.nodes[n]["is_compute"] = float(is_compute)
            self.g.nodes[n]["op_cost"] = float(self.rng.uniform(1.0, 20.0 if is_compute else 10.0))
            self.g.nodes[n]["cpu"] = float(self.rng.uniform(40.0, 100.0) if is_compute else 0.0)
            self.g.nodes[n]["ram"] = float(self.rng.uniform(250.0, 1000.0) if is_compute else 0.0)
            self.g.nodes[n]["gpu"] = float(self.rng.uniform(2500.0, 10000.0) if is_compute else 0.0)
        for u, v in self.g.edges:
            self.g[u][v]["capacity"] = float(self.rng.choice([50.0, 100.0, 200.0]))
            self.g[u][v]["residual"] = self.g[u][v]["capacity"]
            self.g[u][v]["delay"] = float(self.rng.uniform(2.0, 35.0))
            self.g[u][v]["availability"] = float(self.rng.uniform(0.9999, 0.999999))
            self.g[u][v]["cost"] = float(self.rng.uniform(1.0, 10.0))

    def sample_demand(self, max_hops: Optional[int] = None) -> Demand:
        non_compute = [n for n in self.g.nodes if n not in self.compute_nodes]
        source = int(self.rng.choice(non_compute))
        n = self.g.number_of_nodes()
        return Demand(
            source=source,
            bandwidth=float(self.rng.uniform(0.1, 10.0)),
            max_delay=float(self.rng.uniform(50.0, 1000.0)),
            min_availability=float(self.rng.uniform(0.9, 0.999)),
            max_hops=max_hops or max(5, int(round(math.sqrt(n))) + 3),
            cpu=float(self.rng.uniform(1.0, 10.0)),
            ram=float(self.rng.uniform(1.0, 100.0)),
            gpu=float(self.rng.uniform(100.0, 1000.0)),
        )

    def node_features(self, max_nodes: int = 50) -> np.ndarray:
        n = self.g.number_of_nodes()
        x = np.zeros((max_nodes, 5), dtype=np.float32)
        for i in range(n):
            d = self.g.nodes[i]
            x[i] = [
                d["is_compute"],
                d["op_cost"] / 20.0,
                d["cpu"] / 100.0,
                d["ram"] / 1000.0,
                d["gpu"] / 10000.0,
            ]
        return x

    def directed_edge_index_and_features(self) -> Tuple[np.ndarray, np.ndarray]:
        src, dst, attrs = [], [], []
        for u, v, d in self.g.edges(data=True):
            f = [
                d["residual"] / 200.0,
                d["delay"] / 35.0,
                (d["availability"] - 0.9999) / (0.999999 - 0.9999),
                d["cost"] / 10.0,
            ]
            src += [u, v]
            dst += [v, u]
            attrs += [f, f]
        return np.asarray([src, dst], dtype=np.int64), np.asarray(attrs, dtype=np.float32)

    def apply_path(self, path: Sequence[int], demand: Demand) -> None:
        for u, v in zip(path[:-1], path[1:]):
            self.g[u][v]["residual"] = max(0.0, self.g[u][v]["residual"] - demand.bandwidth)
        dest = path[-1]
        self.g.nodes[dest]["cpu"] = max(0.0, self.g.nodes[dest]["cpu"] - demand.cpu)
        self.g.nodes[dest]["ram"] = max(0.0, self.g.nodes[dest]["ram"] - demand.ram)
        self.g.nodes[dest]["gpu"] = max(0.0, self.g.nodes[dest]["gpu"] - demand.gpu)


def path_metrics(state: NetworkState, path: Sequence[int]) -> Dict[str, float]:
    links = [state.g[u][v] for u, v in zip(path[:-1], path[1:])]
    if not links:
        return {"link_cost": math.inf, "total_cost": math.inf, "delay": math.inf,
                "availability": 0.0, "throughput": 0.0, "hops": 0.0}
    link_cost = sum(d["cost"] for d in links)
    dest_cost = state.g.nodes[path[-1]]["op_cost"]
    return {
        "link_cost": link_cost,
        "total_cost": link_cost + dest_cost,
        "delay": sum(d["delay"] for d in links),
        "availability": float(np.prod([d["availability"] for d in links])),
        "throughput": min(d["residual"] for d in links),
        "hops": float(len(path) - 1),
    }


def fitness(state: NetworkState, path: Sequence[int], demand: Demand, penalty_scale: float = 100.0) -> Tuple[float, bool, Dict[str, float]]:
    if len(path) < 2 or path[0] != demand.source or path[-1] not in state.compute_nodes:
        return 1e9, False, {}
    if len(set(path)) != len(path):
        return 1e9, False, {}
    try:
        m = path_metrics(state, path)
    except KeyError:
        return 1e9, False, {}
    dest = state.g.nodes[path[-1]]
    violations = {
        "bandwidth": max(0.0, demand.bandwidth - m["throughput"]) / (demand.bandwidth + 1e-9),
        "delay": max(0.0, m["delay"] - demand.max_delay) / (demand.max_delay + 1e-9),
        "availability": max(0.0, demand.min_availability - m["availability"]) / (demand.min_availability + 1e-9),
        "hops": max(0.0, m["hops"] - demand.max_hops) / max(1.0, demand.max_hops),
        "cpu": max(0.0, demand.cpu - dest["cpu"]) / (demand.cpu + 1e-9),
        "ram": max(0.0, demand.ram - dest["ram"]) / (demand.ram + 1e-9),
        "gpu": max(0.0, demand.gpu - dest["gpu"]) / (demand.gpu + 1e-9),
    }
    p = penalty_scale * sum(violations.values())
    feasible = all(v <= 1e-12 for v in violations.values())
    m.update({f"violation_{k}": v for k, v in violations.items()})
    return m["total_cost"] + p, feasible, m


def candidate_paths(state: NetworkState, demand: Demand, limit: int = 35) -> List[List[int]]:
    """Generate a diverse bounded pool using repeated perturbed shortest paths.

    This is substantially faster and more stable than enumerating all simple paths while
    retaining the paper's BFS/feasible-path-pool intent.
    """
    paths: List[List[int]] = []
    # Deterministic perturbations derived from edge attributes.
    schemes = []
    schemes.append(lambda d: d["cost"])
    schemes.append(lambda d: d["delay"] / 10.0 + 0.2 * d["cost"])
    schemes.append(lambda d: d["cost"] + 8.0 * (1.0 - d["residual"] / max(d["capacity"], 1e-9)))
    schemes.append(lambda d: d["cost"] + 5000.0 * (1.0 - d["availability"]))
    rng = np.random.default_rng(int(demand.source * 100000 + round(demand.bandwidth * 1000)))
    while len(schemes) < max(8, limit // max(1, len(state.compute_nodes)) + 2):
        a, b, c, e = rng.uniform(0.2, 2.0, size=4)
        schemes.append(lambda d, a=a, b=b, c=c, e=e: a*d["cost"] + b*d["delay"]/10.0 + c*(1.0-d["residual"]/max(d["capacity"],1e-9))*10.0 + e*(1.0-d["availability"])*5000.0)
    for si, fn in enumerate(schemes):
        attr = f"search_weight_{si}"
        for _, _, d in state.g.edges(data=True):
            d[attr] = float(fn(d))
            d["search_weight"] = d[attr]
        # One single-source Dijkstra per weighting scheme is substantially faster
        # than independently solving one shortest-path problem per compute node.
        try:
            all_from_source = nx.single_source_dijkstra_path(state.g, demand.source, weight=attr)
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            all_from_source = {}
        for dest in sorted(state.compute_nodes):
            if dest == demand.source or dest not in all_from_source:
                continue
            p = all_from_source[dest]
            if len(p) - 1 <= demand.max_hops:
                paths.append(list(map(int, p)))
            if len(paths) >= limit:
                break
        if len(paths) >= limit:
            break
    unique, seen = [], set()
    for p in paths:
        t = tuple(p)
        if t not in seen:
            seen.add(t)
            unique.append(p)
    # Ensure enough candidates by mutating existing paths if necessary.
    if unique:
        rr = random.Random(int(demand.source + demand.bandwidth * 10000))
        tries = 0
        while len(unique) < min(limit, 12) and tries < 50:
            tries += 1
            q = mutate(state, rr.choice(unique), demand, rr)
            t = tuple(q)
            if t not in seen:
                seen.add(t); unique.append(q)
    return unique[:limit]


def population_masks(population: Sequence[Sequence[int]], max_nodes: int = 50, pop_size: int = 10) -> np.ndarray:
    arr = np.zeros((pop_size, max_nodes), dtype=np.float32)
    for i, p in enumerate(population[:pop_size]):
        for n in p:
            if 0 <= n < max_nodes:
                arr[i, n] = 1.0
    return arr


def path_diversity(population: Sequence[Sequence[int]]) -> float:
    if len(population) < 2:
        return 0.0
    vals = []
    sets = [set(p) for p in population]
    for i in range(len(sets)):
        for j in range(i + 1, len(sets)):
            union = sets[i] | sets[j]
            vals.append(1.0 - len(sets[i] & sets[j]) / max(1, len(union)))
    return float(np.mean(vals))


def tournament(pop: List[List[int]], scores: List[float], rng: random.Random, k: int) -> List[int]:
    ids = [rng.randrange(len(pop)) for _ in range(k)]
    return list(pop[min(ids, key=lambda i: scores[i])])


def repair_path(state: NetworkState, path: Sequence[int], demand: Demand) -> Optional[List[int]]:
    # Remove cycles while preserving order.
    out: List[int] = []
    pos: Dict[int, int] = {}
    for node in path:
        if node in pos:
            cut = pos[node]
            out = out[: cut + 1]
            pos = {v: i for i, v in enumerate(out)}
        else:
            pos[node] = len(out)
            out.append(int(node))
    if not out or out[0] != demand.source:
        return None
    if out[-1] not in state.compute_nodes:
        try:
            nearest = min(
                state.compute_nodes,
                key=lambda d: nx.shortest_path_length(state.g, out[-1], d, weight="search_weight"),
            )
            suffix = nx.shortest_path(state.g, out[-1], nearest, weight="search_weight")
            out += suffix[1:]
        except Exception:
            return None
    if len(out) - 1 > demand.max_hops:
        try:
            out = nx.shortest_path(state.g, demand.source, out[-1], weight="search_weight")
        except Exception:
            return None
    if any(not state.g.has_edge(u, v) for u, v in zip(out[:-1], out[1:])):
        return None
    if len(set(out)) != len(out):
        return None
    return list(map(int, out))


def crossover(state: NetworkState, a: Sequence[int], b: Sequence[int], demand: Demand, rng: random.Random) -> List[int]:
    common = list(set(a[1:-1]) & set(b[1:-1]))
    if not common:
        return list(a if rng.random() < 0.5 else b)
    c = rng.choice(common)
    child = list(a[: a.index(c)]) + list(b[b.index(c):])
    repaired = repair_path(state, child, demand)
    return repaired or list(a)


def mutate(state: NetworkState, p: Sequence[int], demand: Demand, rng: random.Random) -> List[int]:
    if len(p) <= 2:
        return list(p)
    q = list(p)
    i = rng.randrange(1, len(q) - 1)
    left, right = q[i - 1], q[i + 1]
    common = list((set(state.g.neighbors(left)) & set(state.g.neighbors(right))) - set(q))
    if common:
        q[i] = rng.choice(common)
        repaired = repair_path(state, q, demand)
        return repaired or list(p)
    # Alternative suffix mutation.
    j = rng.randrange(0, len(q) - 1)
    try:
        dest = rng.choice(sorted(state.compute_nodes))
        suffix = nx.shortest_path(state.g, q[j], dest, weight="search_weight")
        repaired = repair_path(state, q[:j] + suffix, demand)
        return repaired or list(p)
    except Exception:
        return list(p)


def run_ga_from_population(
    state: NetworkState,
    demand: Demand,
    initial_population: Sequence[Sequence[int]],
    cfg: GAConfig,
    seed: int,
) -> Tuple[Optional[List[int]], float, int]:
    rng = random.Random(seed)
    pop = [list(p) for p in initial_population]
    if not pop:
        return None, 1e9, 0
    while len(pop) < cfg.population_size:
        pop.append(list(rng.choice(pop)))
    pop = pop[: cfg.population_size]
    best_path: Optional[List[int]] = None
    best_score = 1e9
    no_improve = 0
    used_gens = 0
    for gen in range(cfg.generations):
        used_gens = gen + 1
        scores = [fitness(state, p, demand, cfg.penalty_scale)[0] for p in pop]
        idx = int(np.argmin(scores))
        if scores[idx] + 1e-12 < best_score:
            best_score = scores[idx]
            best_path = list(pop[idx])
            no_improve = 0
        else:
            no_improve += 1
        if no_improve >= cfg.stagnation:
            break
        order = np.argsort(scores)
        new_pop = [list(pop[i]) for i in order[: cfg.elite]]
        while len(new_pop) < cfg.population_size:
            p1 = tournament(pop, scores, rng, cfg.tournament_size)
            p2 = tournament(pop, scores, rng, cfg.tournament_size)
            child = crossover(state, p1, p2, demand, rng) if rng.random() < cfg.crossover_rate else list(p1)
            if rng.random() < cfg.mutation_rate:
                child = mutate(state, child, demand, rng)
            new_pop.append(child)
        pop = new_pop
    return best_path, best_score, used_gens


def run_fast_ga_from_population(
    state: NetworkState,
    demand: Demand,
    initial_population: Sequence[Sequence[int]],
    all_paths: Sequence[Sequence[int]],
    cfg: GAConfig,
    seed: int,
) -> Tuple[Optional[List[int]], float, int]:
    """Fast candidate-pool GA used for large reproducible benchmark sweeps.

    The complete path-preserving crossover/mutation implementation remains available in
    run_ga_from_population(). This accelerated form evolves indices into a pre-generated
    feasible path pool, which preserves initialization/selection/mutation effects while
    avoiding repeated graph repairs.
    """
    if not all_paths:
        return None, 1e9, 0
    rng = random.Random(seed)
    path_map = {tuple(p): i for i, p in enumerate(all_paths)}
    scores = [fitness(state, p, demand, cfg.penalty_scale)[0] for p in all_paths]
    pop = [path_map.get(tuple(p), rng.randrange(len(all_paths))) for p in initial_population]
    if not pop:
        pop = [rng.randrange(len(all_paths)) for _ in range(cfg.population_size)]
    while len(pop) < cfg.population_size:
        pop.append(rng.choice(pop))
    pop = pop[:cfg.population_size]
    best_i = min(pop, key=lambda i: scores[i])
    best = scores[best_i]
    stale = 0
    used = 0
    for gen in range(cfg.generations):
        used = gen + 1
        current = min(pop, key=lambda i: scores[i])
        if scores[current] + 1e-12 < best:
            best_i, best, stale = current, scores[current], 0
        else:
            stale += 1
        if stale >= cfg.stagnation:
            break
        new_pop = [best_i]
        while len(new_pop) < cfg.population_size:
            cand1 = [rng.choice(pop) for _ in range(cfg.tournament_size)]
            cand2 = [rng.choice(pop) for _ in range(cfg.tournament_size)]
            p1 = min(cand1, key=lambda i: scores[i])
            p2 = min(cand2, key=lambda i: scores[i])
            child = p1 if rng.random() < 0.5 else p2
            if rng.random() < cfg.mutation_rate:
                child = rng.randrange(len(all_paths))
            new_pop.append(child)
        pop = new_pop
    return list(all_paths[best_i]), float(best), used


def random_population(paths: Sequence[Sequence[int]], cfg: GAConfig, rng: random.Random) -> List[List[int]]:
    if not paths:
        return []
    return [list(rng.choice(paths)) for _ in range(cfg.population_size)]


def aco_population(state: NetworkState, demand: Demand, paths: Sequence[Sequence[int]], cfg: GAConfig, seed: int) -> List[List[int]]:
    """Lightweight GA-ACO-inspired seeding over the candidate path pool."""
    rng = random.Random(seed)
    if not paths:
        return []
    pheromone = {tuple(sorted((u, v))): 1.0 for u, v in state.g.edges}
    scores = []
    for p in paths:
        m = path_metrics(state, p)
        heuristic = 1.0 / (1e-6 + m["total_cost"] + 0.02 * m["delay"])
        tau = np.mean([pheromone[tuple(sorted((u, v)))] for u, v in zip(p[:-1], p[1:])])
        scores.append((tau ** 1.0) * (heuristic ** 2.0))
    probs = np.asarray(scores, dtype=float)
    probs = probs / probs.sum() if probs.sum() > 0 else np.ones(len(paths)) / len(paths)
    selected = [list(paths[int(np.searchsorted(np.cumsum(probs), rng.random(), side="right")) % len(paths)]) for _ in range(cfg.population_size)]
    # One pheromone reinforcement iteration.
    best = min(selected, key=lambda p: fitness(state, p, demand, cfg.penalty_scale)[0])
    dep = 1.0 / (1e-6 + fitness(state, best, demand, cfg.penalty_scale)[0])
    for u, v in zip(best[:-1], best[1:]):
        pheromone[tuple(sorted((u, v)))] += dep
    return selected


# -----------------------------
# GMM-style edge-aware population quality model
# -----------------------------

class GMMMessageLayer(nn.Module):
    def __init__(self, in_dim: int, out_dim: int, edge_dim: int = 4, kernels: int = 4):
        super().__init__()
        self.kernels = kernels
        self.mu = nn.Parameter(torch.rand(kernels, edge_dim))
        self.log_sigma = nn.Parameter(torch.zeros(kernels, edge_dim))
        self.neigh = nn.ModuleList([nn.Linear(in_dim, out_dim, bias=False) for _ in range(kernels)])
        self.self_lin = nn.Linear(in_dim, out_dim)
        self.bias = nn.Parameter(torch.zeros(out_dim))

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor, edge_attr: torch.Tensor) -> torch.Tensor:
        # h: [B,N,F], edge_attr: [B,E,4], edge_index: [2,E]
        src, dst = edge_index[0], edge_index[1]
        sigma = F.softplus(self.log_sigma) + 1e-4
        diff = (edge_attr.unsqueeze(2) - self.mu.view(1, 1, self.kernels, -1)) / sigma.view(1, 1, self.kernels, -1)
        logits = -0.5 * (diff * diff).sum(dim=-1)
        alpha = torch.softmax(logits, dim=-1)  # [B,E,K]
        out = self.self_lin(h)
        deg = torch.zeros(h.shape[0], h.shape[1], 1, device=h.device)
        one = torch.ones(h.shape[0], edge_attr.shape[1], 1, device=h.device)
        deg.index_add_(1, dst, one)
        for k in range(self.kernels):
            msg = self.neigh[k](h[:, src, :]) * alpha[:, :, k:k+1]
            agg = torch.zeros(h.shape[0], h.shape[1], msg.shape[-1], device=h.device)
            agg.index_add_(1, dst, msg)
            out = out + agg / deg.clamp_min(1.0)
        return F.relu(out + self.bias)


class PopulationQualityNet(nn.Module):
    def __init__(self, max_nodes: int = 50, hidden: int = 64, kernels: int = 4, dropout: float = 0.15):
        super().__init__()
        self.max_nodes = max_nodes
        self.node_in = nn.Linear(5, hidden)
        self.g1 = GMMMessageLayer(hidden, hidden, kernels=kernels)
        self.g2 = GMMMessageLayer(hidden, hidden, kernels=kernels)
        self.pop = nn.Sequential(nn.Linear(max_nodes, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU())
        self.head = nn.Sequential(
            nn.Linear(2 * hidden, hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2), nn.ReLU(), nn.Linear(hidden // 2, 1)
        )

    def encode_graph(self, node_x: torch.Tensor, edge_index: torch.Tensor, edge_attr: torch.Tensor, node_valid: torch.Tensor) -> torch.Tensor:
        h = F.relu(self.node_in(node_x))
        h = self.g1(h, edge_index, edge_attr)
        h = self.g2(h, edge_index, edge_attr)
        valid = node_valid.unsqueeze(-1)
        return (h * valid).sum(dim=1) / valid.sum(dim=1).clamp_min(1.0)

    def encode_population(self, pop_mask: torch.Tensor) -> torch.Tensor:
        return self.pop(pop_mask).mean(dim=1)

    def predict_from_embeddings(self, graph_emb: torch.Tensor, pop_emb: torch.Tensor) -> torch.Tensor:
        return self.head(torch.cat([graph_emb, pop_emb], dim=-1)).squeeze(-1)

    def forward(
        self,
        node_x: torch.Tensor,
        edge_index: torch.Tensor,
        edge_attr: torch.Tensor,
        pop_mask: torch.Tensor,
        node_valid: torch.Tensor,
    ) -> torch.Tensor:
        return self.predict_from_embeddings(
            self.encode_graph(node_x, edge_index, edge_attr, node_valid),
            self.encode_population(pop_mask),
        )


@dataclass
class ModelBundle:
    model: PopulationQualityNet
    label_mean: float
    label_std: float
    max_nodes: int = 50


def create_training_dataset(
    topology: nx.Graph,
    ga_cfg: GAConfig,
    samples: int,
    seed: int,
    max_nodes: int = 50,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    state0 = NetworkState(topology, seed=seed)
    edge_index, _ = state0.directed_edge_index_and_features()
    node_valid = np.zeros(max_nodes, dtype=np.float32)
    node_valid[: topology.number_of_nodes()] = 1.0
    nodes, edges, pops, labels = [], [], [], []
    rng = random.Random(seed)
    attempts = 0
    while len(labels) < samples and attempts < samples * 20:
        attempts += 1
        state = NetworkState(topology, seed=seed + attempts * 17)
        demand = state.sample_demand()
        paths = candidate_paths(state, demand, ga_cfg.path_pool_size)
        if len(paths) < 2:
            continue
        pop = random_population(paths, ga_cfg, rng)
        _, score, _ = run_fast_ga_from_population(state, demand, pop, paths, ga_cfg, seed + attempts)
        nodes.append(state.node_features(max_nodes))
        _, ef = state.directed_edge_index_and_features()
        edges.append(ef)
        pops.append(population_masks(pop, max_nodes, ga_cfg.population_size))
        labels.append(math.log1p(score))
    if len(labels) < samples:
        raise RuntimeError(f"Could generate only {len(labels)} training samples")
    return (
        torch.tensor(np.asarray(nodes), dtype=torch.float32),
        torch.tensor(edge_index, dtype=torch.long),
        torch.tensor(np.asarray(edges), dtype=torch.float32),
        torch.tensor(np.asarray(pops), dtype=torch.float32),
        torch.tensor(np.tile(node_valid, (len(labels), 1)), dtype=torch.float32),
        torch.tensor(np.asarray(labels), dtype=torch.float32),
    )


def train_quality_model(
    topology: nx.Graph,
    ga_cfg: GAConfig,
    cfg: TrainConfig,
    seed: int,
    out_dir: Path,
) -> Tuple[ModelBundle, Dict[str, float], pd.DataFrame]:
    set_global_seed(seed)
    data = create_training_dataset(topology, ga_cfg, cfg.samples, seed)
    node_x, edge_index, edge_attr, pop_mask, node_valid, y = data
    n = len(y)
    perm = torch.randperm(n)
    n_val = int(round(n * cfg.validation_fraction))
    val_idx, tr_idx = perm[:n_val], perm[n_val:]
    y_mean = float(y[tr_idx].mean())
    y_std = float(y[tr_idx].std().clamp_min(1e-6))
    y_norm = (y - y_mean) / y_std
    train_ds = TensorDataset(node_x[tr_idx], edge_attr[tr_idx], pop_mask[tr_idx], node_valid[tr_idx], y_norm[tr_idx])
    val_ds = TensorDataset(node_x[val_idx], edge_attr[val_idx], pop_mask[val_idx], node_valid[val_idx], y_norm[val_idx])
    train_loader = DataLoader(train_ds, batch_size=cfg.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=cfg.batch_size, shuffle=False)
    model = PopulationQualityNet(hidden=cfg.hidden, kernels=cfg.kernels, dropout=cfg.dropout)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.learning_rate)
    history = []
    best = math.inf
    best_state = None
    patience = 20
    stale = 0
    t0 = time.perf_counter()
    for epoch in range(1, cfg.epochs + 1):
        model.train()
        tr_losses = []
        for bx, be, bp, bv, by in train_loader:
            opt.zero_grad(set_to_none=True)
            pred = model(bx, edge_index, be, bp, bv)
            loss = F.smooth_l1_loss(pred, by)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            tr_losses.append(float(loss.detach()))
        model.eval()
        va_losses, preds, truth = [], [], []
        with torch.no_grad():
            for bx, be, bp, bv, by in val_loader:
                pred = model(bx, edge_index, be, bp, bv)
                va_losses.append(float(F.smooth_l1_loss(pred, by)))
                preds.append(pred)
                truth.append(by)
        vp = torch.cat(preds)
        vt = torch.cat(truth)
        val_loss = float(np.mean(va_losses))
        ss_res = float(((vp - vt) ** 2).sum())
        ss_tot = float(((vt - vt.mean()) ** 2).sum()) + 1e-12
        r2 = 1.0 - ss_res / ss_tot
        history.append({"epoch": epoch, "train_loss": np.mean(tr_losses), "val_loss": val_loss, "val_r2": r2})
        if val_loss < best - 1e-5:
            best = val_loss
            best_state = copy.deepcopy(model.state_dict())
            stale = 0
        else:
            stale += 1
        if stale >= patience:
            break
    if best_state is not None:
        model.load_state_dict(best_state)
    elapsed = time.perf_counter() - t0
    model.eval()
    with torch.no_grad():
        pred = model(node_x[val_idx], edge_index, edge_attr[val_idx], pop_mask[val_idx], node_valid[val_idx])
    pred_un = torch.expm1(pred * y_std + y_mean).clamp_min(0)
    true_un = torch.expm1(y[val_idx]).clamp_min(0)
    mae = float(torch.mean(torch.abs(pred_un - true_un)))
    mape = float(torch.mean(torch.abs(pred_un - true_un) / true_un.clamp_min(1e-6)))
    metrics = {"best_val_loss": best, "val_mae_fitness": mae, "val_mape": mape, "training_seconds": elapsed, "epochs_run": len(history)}
    out_dir.mkdir(parents=True, exist_ok=True)
    torch.save({"state_dict": model.state_dict(), "label_mean": y_mean, "label_std": y_std, "train_config": asdict(cfg)}, out_dir / "population_quality_gmm.pt")
    pd.DataFrame(history).to_csv(out_dir / "training_history.csv", index=False)
    return ModelBundle(model, y_mean, y_std), metrics, pd.DataFrame(history)


def load_quality_model(checkpoint: Path) -> ModelBundle:
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    cfg_dict = payload.get("train_config", {})
    model = PopulationQualityNet(
        hidden=int(cfg_dict.get("hidden", 64)),
        kernels=int(cfg_dict.get("kernels", 4)),
        dropout=float(cfg_dict.get("dropout", 0.15)),
    )
    model.load_state_dict(payload["state_dict"])
    model.eval()
    return ModelBundle(model, float(payload["label_mean"]), float(payload["label_std"]))


def score_populations(
    bundle: ModelBundle,
    state: NetworkState,
    populations: Sequence[Sequence[Sequence[int]]],
    mc_samples: int = 1,
    edge_ablation: bool = False,
    topology_ablation: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    model = bundle.model
    max_nodes = bundle.max_nodes
    node = state.node_features(max_nodes)
    edge_index, edge = state.directed_edge_index_and_features()
    if edge_ablation:
        edge = np.zeros_like(edge)
    if topology_ablation:
        node = np.zeros_like(node)
        edge = np.zeros_like(edge)
    p = np.asarray([population_masks(x, max_nodes, len(x)) for x in populations], dtype=np.float32)
    b = len(populations)
    node_t = torch.tensor(node[None, ...], dtype=torch.float32)
    edge_t = torch.tensor(edge[None, ...], dtype=torch.float32)
    pop_b = torch.tensor(p, dtype=torch.float32)
    valid = np.zeros(max_nodes, dtype=np.float32)
    valid[: state.g.number_of_nodes()] = 1.0
    valid_t = torch.tensor(valid[None, ...], dtype=torch.float32)
    ei = torch.tensor(edge_index, dtype=torch.long)
    # Graph encoding is shared by all candidate populations and all MC-dropout draws.
    model.eval()
    with torch.no_grad():
        graph_emb = model.encode_graph(node_t, ei, edge_t, valid_t).repeat(b, 1)
        pop_emb = model.encode_population(pop_b)
    preds = []
    if mc_samples > 1:
        model.train()
    else:
        model.eval()
    with torch.no_grad():
        for _ in range(mc_samples):
            z = model.predict_from_embeddings(graph_emb, pop_emb)
            raw = torch.expm1(z * bundle.label_std + bundle.label_mean).clamp_min(0)
            preds.append(raw.numpy())
    model.eval()
    arr = np.asarray(preds)
    return arr.mean(axis=0), arr.std(axis=0)


def solve_one(
    method: str,
    state: NetworkState,
    demand: Demand,
    ga_cfg: GAConfig,
    seed: int,
    bundle: Optional[ModelBundle] = None,
    ablation: Optional[str] = None,
) -> Dict[str, float | int | bool | str]:
    t0 = time.perf_counter()
    paths = candidate_paths(state, demand, ga_cfg.path_pool_size)
    rng = random.Random(seed)
    chosen: Optional[List[int]] = None
    generations = 0
    predicted_std = 0.0
    if not paths:
        return {"success": False, "fitness": 1e9, "cost": np.nan, "delay": np.nan, "throughput": np.nan, "runtime": time.perf_counter() - t0, "generations": 0, "uncertainty": 0.0}

    if method == "Dijkstra":
        # Minimum operating-cost candidate, matching the paper's baseline intent.
        chosen = min(paths, key=lambda p: path_metrics(state, p)["total_cost"])
    elif method == "CGA":
        pop = random_population(paths, ga_cfg, rng)
        chosen, _, generations = run_fast_ga_from_population(state, demand, pop, paths, ga_cfg, seed)
    elif method == "HGA-ACO":
        pop = aco_population(state, demand, paths, ga_cfg, seed)
        chosen, _, generations = run_fast_ga_from_population(state, demand, pop, paths, ga_cfg, seed)
    elif method in {"EAGA", "RD-EAGA"}:
        if bundle is None:
            raise ValueError("A trained model bundle is required")
        pops = [random_population(paths, ga_cfg, random.Random(seed + 1009 * i)) for i in range(ga_cfg.candidate_populations)]
        edge_ab = ablation == "no_edge_features"
        topo_ab = ablation == "population_only"
        mc = 3 if method == "RD-EAGA" and ablation != "no_uncertainty" else 1
        mean, std = score_populations(bundle, state, pops, mc_samples=mc, edge_ablation=edge_ab, topology_ablation=topo_ab)
        predicted_std = float(np.mean(std))
        if method == "RD-EAGA":
            beta = 0.35 if ablation != "no_uncertainty" else 0.0
            lam = 3.0 if ablation != "no_diversity" else 0.0
            score = mean + beta * std + lam * np.asarray([1.0 - path_diversity(p) for p in pops])
        else:
            score = mean
        pop = pops[int(np.argmin(score))]
        chosen, _, generations = run_fast_ga_from_population(state, demand, pop, paths, ga_cfg, seed)
    else:
        raise ValueError(method)

    runtime = time.perf_counter() - t0
    if chosen is None:
        return {"success": False, "fitness": 1e9, "cost": np.nan, "delay": np.nan, "throughput": np.nan, "runtime": runtime, "generations": generations, "uncertainty": predicted_std}
    fit, feasible, m = fitness(state, chosen, demand, ga_cfg.penalty_scale)
    if feasible:
        state.apply_path(chosen, demand)
    return {
        "success": feasible,
        "fitness": fit,
        "cost": m.get("total_cost", np.nan),
        "delay": m.get("delay", np.nan),
        "throughput": m.get("throughput", np.nan),
        "runtime": runtime,
        "generations": generations,
        "uncertainty": predicted_std,
    }


def _benchmark_scenario(task: Tuple[ModelBundle, GAConfig, str, int, int, str, int, int]) -> List[Dict[str, object]]:
    """Execute one topology/load/repetition scenario in an isolated worker."""
    bundle, ga_cfg, topo_name, load, rep, topology_source, seed, topo_i = task
    torch.set_num_threads(1)
    methods = ["Dijkstra", "CGA", "EAGA", "HGA-ACO", "RD-EAGA"]
    topo = load_topology(topo_name, topology_source)
    base_seed = seed + topo_i * 100000 + load * 100 + rep
    base = NetworkState(topo, seed=base_seed)
    demands = [base.sample_demand() for _ in range(load)]
    rows: List[Dict[str, object]] = []
    for method_i, method in enumerate(methods):
        state = base.clone()
        per = [
            solve_one(method, state, d, ga_cfg, base_seed + method_i * 10000 + j, bundle)
            for j, d in enumerate(demands)
        ]
        df = pd.DataFrame(per)
        succ = df[df["success"] == True]  # noqa: E712
        rows.append({
            "topology": topo_name,
            "topology_source": topo.graph.get("topology_source", "unknown"),
            "load": load,
            "repetition": rep,
            "method": method,
            "success_rate": float(df["success"].mean()),
            "total_cost": float(succ["cost"].sum()),
            "avg_cost": float(succ["cost"].mean()) if len(succ) else np.nan,
            "avg_delay": float(succ["delay"].mean()) if len(succ) else np.nan,
            "avg_throughput": float(succ["throughput"].mean()) if len(succ) else np.nan,
            "avg_runtime": float(df["runtime"].mean()),
            "avg_generations": float(df["generations"].mean()),
            "avg_uncertainty": float(df["uncertainty"].mean()),
        })
    return rows


def run_benchmark(
    bundle: ModelBundle,
    ga_cfg: GAConfig,
    loads: Sequence[int],
    repetitions: int,
    topology_source: str,
    seed: int,
    workers: int = 1,
) -> pd.DataFrame:
    topologies = ["abilene", "geant", "janos-us-ca", "giul39"]
    tasks = [
        (bundle, ga_cfg, topo_name, int(load), rep, topology_source, seed, topo_i)
        for topo_i, topo_name in enumerate(topologies)
        for load in loads
        for rep in range(repetitions)
    ]
    rows: List[Dict[str, object]] = []
    if workers <= 1:
        for task in tasks:
            result = _benchmark_scenario(task)
            rows.extend(result)
            print(f"done {task[2]} load={task[3]} rep={task[4]}", flush=True)
    else:
        with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(_benchmark_scenario, task): task for task in tasks}
            for fut in concurrent.futures.as_completed(futs):
                task = futs[fut]
                rows.extend(fut.result())
                print(f"done {task[2]} load={task[3]} rep={task[4]}", flush=True)
    return pd.DataFrame(rows).sort_values(["topology", "load", "repetition", "method"]).reset_index(drop=True)


def _ablation_rep(task: Tuple[ModelBundle, GAConfig, int, int, str]) -> List[Dict[str, object]]:
    bundle, ga_cfg, rep, seed, topology_source = task
    torch.set_num_threads(1)
    topo = load_topology("giul39", topology_source)
    load = 30
    variants = [
        ("Full RD-EAGA", "RD-EAGA", None),
        ("No uncertainty", "RD-EAGA", "no_uncertainty"),
        ("No diversity", "RD-EAGA", "no_diversity"),
        ("No edge features", "RD-EAGA", "no_edge_features"),
        ("Population-only scorer", "RD-EAGA", "population_only"),
        ("Random initialization", "CGA", None),
    ]
    base_seed = seed + 700000 + rep
    base = NetworkState(topo, seed=base_seed)
    demands = [base.sample_demand() for _ in range(load)]
    rows: List[Dict[str, object]] = []
    for v_i, (label, method, abl) in enumerate(variants):
        state = base.clone()
        per = [solve_one(method, state, d, ga_cfg, base_seed + v_i * 10000 + j, bundle, abl) for j, d in enumerate(demands)]
        df = pd.DataFrame(per)
        succ = df[df["success"] == True]  # noqa: E712
        rows.append({
            "variant": label,
            "repetition": rep,
            "success_rate": float(df["success"].mean()),
            "total_cost": float(succ["cost"].sum()),
            "avg_cost": float(succ["cost"].mean()) if len(succ) else np.nan,
            "avg_delay": float(succ["delay"].mean()) if len(succ) else np.nan,
            "avg_runtime": float(df["runtime"].mean()),
            "avg_generations": float(df["generations"].mean()),
        })
    return rows


def run_ablation(bundle: ModelBundle, ga_cfg: GAConfig, repetitions: int, seed: int, topology_source: str, workers: int = 1) -> pd.DataFrame:
    tasks = [(bundle, ga_cfg, rep, seed, topology_source) for rep in range(repetitions)]
    rows: List[Dict[str, object]] = []
    if workers <= 1:
        for task in tasks:
            rows.extend(_ablation_rep(task))
            print(f"ablation rep={task[2]}", flush=True)
    else:
        with concurrent.futures.ProcessPoolExecutor(max_workers=min(workers, repetitions)) as ex:
            futs = {ex.submit(_ablation_rep, task): task for task in tasks}
            for fut in concurrent.futures.as_completed(futs):
                task = futs[fut]
                rows.extend(fut.result())
                print(f"ablation rep={task[2]}", flush=True)
    return pd.DataFrame(rows).sort_values(["variant", "repetition"]).reset_index(drop=True)

def summarize(df: pd.DataFrame, group_cols: Sequence[str]) -> pd.DataFrame:
    metrics = [c for c in ["success_rate", "total_cost", "avg_cost", "avg_delay", "avg_throughput", "avg_runtime", "avg_generations"] if c in df.columns]
    agg = df.groupby(list(group_cols))[metrics].agg(["mean", "std"]).reset_index()
    agg.columns = ["_".join([str(x) for x in col if str(x)]) for col in agg.columns.to_flat_index()]
    return agg


def plot_results(summary_df: pd.DataFrame, fig_dir: Path) -> None:
    fig_dir.mkdir(parents=True, exist_ok=True)
    for metric, ylabel in [
        ("success_rate_mean", "Routing success rate"),
        ("avg_cost_mean", "Average operational cost"),
        ("avg_delay_mean", "Average latency"),
        ("avg_runtime_mean", "Runtime per demand (s)"),
    ]:
        for topo in summary_df["topology"].unique():
            s = summary_df[summary_df["topology"] == topo]
            plt.figure(figsize=(7.2, 4.5))
            for method in s["method"].unique():
                q = s[s["method"] == method].sort_values("load")
                plt.plot(q["load"], q[metric], marker="o", label=method)
            plt.xlabel("Number of service demands")
            plt.ylabel(ylabel)
            plt.title(f"{ylabel} - {topo}")
            plt.grid(alpha=0.25)
            plt.legend(fontsize=8)
            plt.tight_layout()
            plt.savefig(fig_dir / f"{metric}_{topo}.png", dpi=180)
            plt.close()


def plot_ablation(ab_summary: pd.DataFrame, fig_dir: Path) -> None:
    fig_dir.mkdir(parents=True, exist_ok=True)
    x = np.arange(len(ab_summary))
    plt.figure(figsize=(9, 4.8))
    plt.bar(x, ab_summary["success_rate_mean"])
    plt.xticks(x, ab_summary["variant"], rotation=25, ha="right")
    plt.ylabel("Success rate")
    plt.title("Ablation study on Giul39-scale topology (100 demands)")
    plt.tight_layout()
    plt.savefig(fig_dir / "ablation_success_rate.png", dpi=180)
    plt.close()


def plot_training(history: pd.DataFrame, fig_dir: Path) -> None:
    plt.figure(figsize=(7, 4.5))
    plt.plot(history["epoch"], history["train_loss"], label="Train")
    plt.plot(history["epoch"], history["val_loss"], label="Validation")
    plt.xlabel("Epoch")
    plt.ylabel("Smooth L1 loss")
    plt.title("Population-quality predictor training")
    plt.grid(alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(fig_dir / "training_curve.png", dpi=180)
    plt.close()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", default=".")
    ap.add_argument("--seed", type=int, default=20260803)
    ap.add_argument("--topology-source", choices=["auto", "surrogate", "topohub", "bundled"], default="auto")
    ap.add_argument("--train-samples", type=int, default=2500)
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--repetitions", type=int, default=5)
    ap.add_argument("--ablation-repetitions", type=int, default=5)
    ap.add_argument("--loads", type=int, nargs="+", default=[50, 75, 100, 200])
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--workers", type=int, default=1, help="Parallel scenario workers")
    ap.add_argument("--skip-training", action="store_true")
    ap.add_argument("--skip-benchmark", action="store_true")
    ap.add_argument("--skip-ablation", action="store_true")
    ap.add_argument("--checkpoint", default=None, help="Checkpoint used with --skip-training")
    args = ap.parse_args()
    out = Path(args.output)
    (out / "results").mkdir(parents=True, exist_ok=True)
    (out / "figures").mkdir(parents=True, exist_ok=True)
    (out / "models").mkdir(parents=True, exist_ok=True)

    set_global_seed(args.seed)
    ga = GAConfig()
    train_cfg = TrainConfig(samples=args.train_samples, epochs=args.epochs)
    reps = args.repetitions
    ab_reps = args.ablation_repetitions
    loads = args.loads
    if args.quick:
        ga.generations = 15
        ga.stagnation = 3
        ga.path_pool_size = 15
        ga.candidate_populations = 4
        train_cfg.samples = min(train_cfg.samples, 1200)
        train_cfg.epochs = min(train_cfg.epochs, 45)

    train_topo = load_topology("germany50", args.topology_source)
    if args.skip_training:
        checkpoint = Path(args.checkpoint) if args.checkpoint else out / "models" / "population_quality_gmm.pt"
        bundle = load_quality_model(checkpoint)
        metrics_path = checkpoint.parent.parent / "results" / "training_metrics.json"
        train_metrics = json.loads(metrics_path.read_text(encoding="utf-8")) if metrics_path.exists() else {"loaded_checkpoint": str(checkpoint)}
        history_path = checkpoint.parent / "training_history.csv"
        history = pd.read_csv(history_path) if history_path.exists() else pd.DataFrame()
    else:
        bundle, train_metrics, history = train_quality_model(train_topo, ga, train_cfg, args.seed, out / "models")
        (out / "results" / "training_metrics.json").write_text(json.dumps(train_metrics, indent=2), encoding="utf-8")
        plot_training(history, out / "figures")

    raw = pd.DataFrame()
    abl = pd.DataFrame()
    if not args.skip_benchmark:
        raw = run_benchmark(bundle, ga, loads, reps, args.topology_source, args.seed, args.workers)
        raw.to_csv(out / "results" / "benchmark_raw.csv", index=False)
        summ = summarize(raw, ["topology", "method", "load"])
        summ.to_csv(out / "results" / "benchmark_summary.csv", index=False)
        plot_results(summ, out / "figures")

    if not args.skip_ablation and ab_reps > 0:
        abl = run_ablation(bundle, ga, ab_reps, args.seed, args.topology_source, args.workers)
        abl.to_csv(out / "results" / "ablation_raw.csv", index=False)
        abl_s = summarize(abl, ["variant"])
        abl_s.to_csv(out / "results" / "ablation_summary.csv", index=False)
        plot_ablation(abl_s, out / "figures")

    metadata = {
        "seed": args.seed,
        "ga_config": asdict(ga),
        "train_config": asdict(train_cfg),
        "loads": loads,
        "repetitions": reps,
        "ablation_repetitions": ab_reps,
        "topology_source_requested": args.topology_source,
        "workers": args.workers,
        "training_topology_source": train_topo.graph.get("topology_source"),
        "software": {"python": os.sys.version, "torch": torch.__version__, "networkx": nx.__version__, "numpy": np.__version__, "pandas": pd.__version__},
    }
    (out / "results" / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps({"training": train_metrics, "rows": len(raw), "ablation_rows": len(abl)}, indent=2))


if __name__ == "__main__":
    main()
