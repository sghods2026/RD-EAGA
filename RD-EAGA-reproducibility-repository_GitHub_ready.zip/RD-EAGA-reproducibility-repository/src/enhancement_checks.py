from pathlib import Path
import sys, random, json, math
import numpy as np, pandas as pd, torch
from scipy.stats import pearsonr, spearmanr
from statsmodels.stats.multitest import multipletests
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
import eaga_reproduction as er

RES=ROOT/'results'; RES.mkdir(exist_ok=True)

def bootstrap_ci(x, nboot=10000, seed=20260808):
    x=np.asarray(pd.Series(x).dropna(),dtype=float)
    if len(x)==0:return (np.nan,np.nan)
    rng=np.random.default_rng(seed)
    means=np.mean(rng.choice(x,size=(nboot,len(x)),replace=True),axis=1)
    return tuple(np.percentile(means,[2.5,97.5]))

def adjust_p():
    p=RES/'statistical_tests.csv'; df=pd.read_csv(p); vals=df['wilcoxon_p'].to_numpy()
    df['p_adjusted_holm']=multipletests(vals,method='holm')[1]
    df['p_adjusted_bh']=multipletests(vals,method='fdr_bh')[1]
    df['significant_holm_0.05']=df['p_adjusted_holm']<.05
    df['significant_bh_0.05']=df['p_adjusted_bh']<.05
    df.to_csv(p,index=False)

def bootstrap_tables():
    raw=pd.read_csv(RES/'benchmark_raw.csv')
    # Table 10: overall means across 80 scenario-runs/method
    rows=[]
    for method,g in raw.groupby('method'):
        r={'method':method,'n':len(g)}
        for metric in ['success_rate','avg_cost','avg_delay','avg_throughput','avg_runtime','avg_generations']:
            x=g[metric].dropna().to_numpy(); lo,hi=bootstrap_ci(x)
            r[f'{metric}_mean']=np.mean(x); r[f'{metric}_ci95_low']=lo; r[f'{metric}_ci95_high']=hi
        rows.append(r)
    pd.DataFrame(rows).to_csv(RES/'table10_bootstrap_ci.csv',index=False)
    # Table 11: paired relative changes RD-EAGA vs each baseline, bootstrap paired mean change
    rd=raw[raw.method=='RD-EAGA'].set_index(['topology','load','repetition'])
    rows=[]
    for base in ['Dijkstra','CGA','EAGA','HGA-ACO']:
        b=raw[raw.method==base].set_index(['topology','load','repetition']); idx=rd.index.intersection(b.index)
        r={'baseline':base,'n':len(idx)}
        for metric in ['success_rate','avg_cost','avg_delay','avg_throughput','avg_runtime']:
            a=rd.loc[idx,metric].to_numpy(); c=b.loc[idx,metric].to_numpy(); mask=np.isfinite(a)&np.isfinite(c); a=a[mask]; c=c[mask]
            if metric=='success_rate': d=100*(a-c)
            else: d=100*(a-c)/np.where(np.abs(c)>1e-12,np.abs(c),np.nan)
            d=d[np.isfinite(d)]; lo,hi=bootstrap_ci(d)
            r[f'{metric}_change_mean']=np.mean(d); r[f'{metric}_change_ci95_low']=lo; r[f'{metric}_change_ci95_high']=hi
        rows.append(r)
    pd.DataFrame(rows).to_csv(RES/'table11_bootstrap_ci.csv',index=False)
    # Table 15 ablation
    abl=pd.read_csv(RES/'ablation_raw.csv'); rows=[]
    for variant,g in abl.groupby('variant'):
        r={'variant':variant,'n':len(g)}
        for metric in ['success_rate','avg_cost','avg_delay','avg_runtime']:
            x=g[metric].dropna().to_numpy(); lo,hi=bootstrap_ci(x); r[f'{metric}_mean']=np.mean(x); r[f'{metric}_ci95_low']=lo; r[f'{metric}_ci95_high']=hi
        rows.append(r)
    pd.DataFrame(rows).to_csv(RES/'table15_bootstrap_ci.csv',index=False)

def calibration():
    seed=20260803; er.set_global_seed(seed)
    ga=er.GAConfig(); ga.generations=15; ga.stagnation=3; ga.path_pool_size=15; ga.candidate_populations=4
    topo=er.load_topology('germany50','auto')
    ck=torch.load(ROOT/'models'/'population_quality_gmm.pt',map_location='cpu',weights_only=False)
    cfg=er.TrainConfig(**ck['train_config'])
    data=er.create_training_dataset(topo,ga,cfg.samples,seed)
    node_x, edge_index, edge_attr, pop_mask, node_valid, y=data
    n=len(y); perm=torch.randperm(n); n_val=int(round(n*cfg.validation_fraction)); vidx=perm[:n_val]
    bundle=er.load_quality_model(ROOT/'models'/'population_quality_gmm.pt'); model=bundle.model
    bx=node_x[vidx]; be=edge_attr[vidx]; bp=pop_mask[vidx]; bv=node_valid[vidx]
    truth=torch.expm1(y[vidx]).numpy()
    rows=[]; summary=[]
    for T in [3,10,20]:
        preds=[]; model.train()
        with torch.no_grad():
            for _ in range(T):
                z=model(bx,edge_index,be,bp,bv); raw=torch.expm1(z*bundle.label_std+bundle.label_mean).clamp_min(0); preds.append(raw.numpy())
        model.eval(); arr=np.asarray(preds); mu=arr.mean(0); sig=arr.std(0); err=np.abs(mu-truth)
        pr=pearsonr(sig,err); sr=spearmanr(sig,err)
        summary.append({'T':T,'n':len(truth),'pearson_r':pr.statistic,'pearson_p':pr.pvalue,'spearman_rho':sr.statistic,'spearman_p':sr.pvalue,'mean_sigma':sig.mean(),'mae':err.mean()})
        for i in range(len(truth)): rows.append({'T':T,'validation_index':int(vidx[i]),'true_q':truth[i],'pred_mean':mu[i],'pred_sigma':sig[i],'abs_error':err[i]})
    pd.DataFrame(summary).to_csv(RES/'mc_dropout_calibration_summary.csv',index=False)
    pd.DataFrame(rows).to_csv(RES/'mc_dropout_calibration_raw.csv',index=False)
    # T=3 vs T=10/20 comparison
    wide=pd.DataFrame(rows).pivot(index='validation_index',columns='T',values=['pred_mean','pred_sigma'])
    comp=[]
    for T in [10,20]:
        dm=np.abs(wide['pred_mean'][T]-wide['pred_mean'][3]); ds=np.abs(wide['pred_sigma'][T]-wide['pred_sigma'][3])
        comp.append({'comparison':f'T=3 vs T={T}','mean_abs_mean_difference':dm.mean(),'median_abs_mean_difference':dm.median(),'mean_abs_sigma_difference':ds.mean(),'median_abs_sigma_difference':ds.median()})
    pd.DataFrame(comp).to_csv(RES/'mc_dropout_T_sensitivity.csv',index=False)

def random_compute_state(topo,seed):
    st=er.NetworkState(topo,seed=seed)
    nodes=list(st.g.nodes); k=max(2,int(round(len(nodes)*0.13))); rng=np.random.default_rng(seed+99173)
    st.compute_nodes=set(int(x) for x in rng.choice(nodes,size=k,replace=False)); st.rng=np.random.default_rng(seed); st._assign_dynamic_attributes(); return st

def robustness_random_compute():
    bundle=er.load_quality_model(ROOT/'models'/'population_quality_gmm.pt'); ga=er.GAConfig(); ga.generations=15; ga.stagnation=3; ga.path_pool_size=15; ga.candidate_populations=4
    methods=['Dijkstra','CGA','EAGA','HGA-ACO','RD-EAGA']; rows=[]; load=50
    for topo_i,name in enumerate(['abilene','giul39']):
        topo=er.load_topology(name,'auto')
        for rep,seed in enumerate([20260803,20260804,20260805]):
            base_seed=seed+topo_i*100000+load*100+rep; base=random_compute_state(topo,base_seed); demands=[base.sample_demand() for _ in range(load)]
            for mi,m in enumerate(methods):
                st=base.clone(); per=[er.solve_one(m,st,d,ga,base_seed+mi*10000+j,bundle) for j,d in enumerate(demands)]; df=pd.DataFrame(per); s=df[df.success==True]
                rows.append({'topology':name,'seed':seed,'method':m,'success_rate':df.success.mean(),'avg_cost':s.cost.mean(),'avg_delay':s.delay.mean(),'avg_throughput':s.throughput.mean(),'avg_runtime':df.runtime.mean()})
    out=pd.DataFrame(rows); out.to_csv(RES/'random_compute_robustness_raw.csv',index=False)
    summ=out.groupby(['topology','method']).agg({'success_rate':'mean','avg_cost':'mean','avg_delay':'mean','avg_throughput':'mean','avg_runtime':'mean'}).reset_index()
    for topo in summ.topology.unique():
        g=summ[summ.topology==topo].copy(); g['cost_rank']=g.avg_cost.rank(method='min'); g['success_rank']=g.success_rate.rank(method='min',ascending=False); summ.loc[g.index,'cost_rank']=g.cost_rank; summ.loc[g.index,'success_rank']=g.success_rank
    summ.to_csv(RES/'random_compute_robustness_summary.csv',index=False)

def ablation_second_topology():
    bundle=er.load_quality_model(ROOT/'models'/'population_quality_gmm.pt'); ga=er.GAConfig(); ga.generations=15; ga.stagnation=3; ga.path_pool_size=15; ga.candidate_populations=4
    topo=er.load_topology('janos-us-ca','auto'); load=30; variants=[('Full RD-EAGA','RD-EAGA',None),('No uncertainty','RD-EAGA','no_uncertainty'),('No diversity','RD-EAGA','no_diversity'),('No edge features','RD-EAGA','no_edge_features'),('Population-only scorer','RD-EAGA','population_only'),('Random initialization','CGA',None)]
    rows=[]
    for rep in range(10):
        base_seed=20260803+800000+rep; base=er.NetworkState(topo,seed=base_seed); demands=[base.sample_demand() for _ in range(load)]
        for vi,(label,m,abl) in enumerate(variants):
            st=base.clone(); per=[er.solve_one(m,st,d,ga,base_seed+vi*10000+j,bundle,abl) for j,d in enumerate(demands)]; df=pd.DataFrame(per); s=df[df.success==True]
            rows.append({'topology':'janos-us-ca','variant':label,'repetition':rep,'success_rate':df.success.mean(),'total_cost':s.cost.sum(),'avg_cost':s.cost.mean(),'avg_delay':s.delay.mean(),'avg_runtime':df.runtime.mean(),'avg_generations':df.generations.mean()})
    out=pd.DataFrame(rows); out.to_csv(RES/'ablation_janos_raw.csv',index=False); out.groupby('variant')[[c for c in out.columns if c not in ['topology','variant']]].agg(['mean','std']).to_csv(RES/'ablation_janos_summary.csv')

if __name__=='__main__':
    adjust_p(); bootstrap_tables(); calibration(); robustness_random_compute(); ablation_second_topology()
