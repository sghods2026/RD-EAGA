#!/usr/bin/env bash
# Re-executes the "executed verification profile" of the manuscript (Appendix A.2).
# Run from the repository root:  bash src/reproduce_executed_profile.sh
# WARNING: this script writes into the repository (models/, runs/, results/*.csv, figures/) and
# overwrites the archived benchmark/ablation outputs. Run it in a fresh copy of the repository.
# Set PYTHON=python3 (default: python) if needed; WORKERS sets the number of parallel scenario workers.
set -euo pipefail
PYTHON="${PYTHON:-python}"
WORKERS="${WORKERS:-4}"
# 1) train the small verification model (200 labelled samples, 15 epochs, seed 20260803)
"$PYTHON" src/eaga_reproduction.py --output . --quick --topology-source bundled --train-samples 200 --epochs 15 --skip-benchmark --skip-ablation
# 2) ten independent benchmark seeds (20260803 ... 20260812), shipped/retrained checkpoint, no ablation
for i in 0 1 2 3 4 5 6 7 8 9; do
  seed=$((20260803+i))
  run=$((i+1))
  mkdir -p "runs/run${run}/results" "runs/run${run}/figures" "runs/run${run}/models"
  "$PYTHON" src/eaga_reproduction.py --output "runs/run${run}" --quick --topology-source bundled --skip-training --checkpoint models/population_quality_gmm.pt --skip-ablation --repetitions 1 --loads 50 75 100 200 --workers "$WORKERS" --seed "$seed"
done
# 3) ablation study (10 repetitions)
"$PYTHON" src/eaga_reproduction.py --output . --quick --topology-source bundled --skip-training --checkpoint models/population_quality_gmm.pt --skip-benchmark --ablation-repetitions 10 --workers "$WORKERS" --seed 20260803
# 4) merge runs/run*/ into results/benchmark_raw.csv and compute legacy tables/figures
"$PYTHON" src/postprocess_results.py
