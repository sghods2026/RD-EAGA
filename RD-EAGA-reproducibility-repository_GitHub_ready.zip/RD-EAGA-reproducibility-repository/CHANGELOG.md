# Changelog (relative to the original archive "RD-EAGA-reproducibility-repository")

## Fixed
- `src/eaga_reproduction.py`: `load_topology` looked for `data/<name>.gml` while the archive stores the files in `data/topologies/`, so a fresh run silently used a synthetic surrogate graph. It now searches both locations, accepts `--topology-source bundled` (hard error if the file is missing) and warns when the surrogate is used in `auto` mode. The archived results (all 800 rows record "bundled TopoHub/SNDlib GML") were not affected.
- `src/postprocess_results.py`: topology plot read `data/<name>.gml` (FileNotFoundError with the released layout); now uses `data/topologies/`.
- `src/reproduce_executed_profile.sh`: `--topology-source bundled`, configurable `PYTHON`/`WORKERS`, header warning that it overwrites outputs.
- `environment/requirements.txt` replaced by the pinned versions of the manuscript (Sec. 3.5).

## Added
- `scripts/` (seed-cluster analysis, training-size and generation-budget sensitivity, checkpoint retrain check, figure generation) with argparse defaults and no hard-coded paths; `patches/load_topology.patch`.
- `results/seed_cluster/`, `results/training_sensitivity_seeds*.csv`, `results/generation_sensitivity_seeds*.csv`, `results/benchmark_replay_check.csv`, `results/checkpoint_retrain_check.json`; `figures/` (vector + PNG).
- `README.md`, `results/README.md`, `CITATION.cff` (TODO author fields), `.gitignore`, this file.

## Removed / moved
- `paper/` (LaTeX/BibTeX/citation audit of an earlier manuscript draft; does not match the final paper), `src/update_manuscript.py` (edits a stale draft .docx that is not shipped), `src/__pycache__/`, duplicate `data/*.gml`.
- `results/{hierarchical_blocked_stats,failure_aware_utility,training_sensitivity,generation_sensitivity}.csv` moved to `results/superseded/`.
